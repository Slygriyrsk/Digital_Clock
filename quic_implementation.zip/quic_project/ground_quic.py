#!/usr/bin/env python3
"""
ground_quic.py — Ground station receiver over QUIC (RFC 9000 + TLS 1.3).

What's different from ground.py:
  - Transport : UDP raw  →  QUIC (aioquic) with TLS 1.3
  - Auth      : HMAC-SHA256 per-pkt  →  AEAD from TLS 1.3 (still verifies ECDSA on bundle)
  - Streams   : BUNDLE_STREAM_ID=0 (chunks in), ACK_STREAM_ID=4 (acks out),
                META_STREAM_ID=8 (JSON diagnostic events out)
  - Everything else (FEC, bitmap ACK, decompress, ECDSA verify, file save) is IDENTICAL

Run:
  python gen_certs.py          # once
  python ground_quic.py --port 9010 --name GS-QUIC-Primary
  python ground_quic.py --port 9011 --name GS-QUIC-Backup
"""

import argparse
import asyncio
import json
import os
import struct
import sys
import time
import wave
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import config as cfg
from crypto        import ecdsa_verify, load_ecdsa_public
from compress      import decompress_bundle, BUNDLE_HDR_SZ, BUNDLE_FMT
from protocol_quic import (
    parse_packet, make_ack, fec_recover,
    FLAG_PARITY, FLAG_RETX, FEC_K, ACK_STREAM_ID, META_STREAM_ID
)

from aioquic.asyncio        import serve
from aioquic.asyncio.protocol import QuicConnectionProtocol
from aioquic.quic.configuration import QuicConfiguration
from aioquic.quic.connection import QuicConnection
from aioquic.quic.events    import (StreamDataReceived, ConnectionTerminated,
                                     HandshakeCompleted)

os.makedirs("output/received", exist_ok=True)

CERT_PATH = "certs/quic_cert.pem"
KEY_PATH  = "certs/quic_key.pem"

# ── Shared state (written by ground, read by GUI subprocess pipe) ─────────────
_gs_name   = "GS-QUIC-Primary"
_quic_log  = []          # list of QUIC diagnostic event dicts


def _log_quic(event: dict):
    event["_t"] = round(time.time(), 4)
    _quic_log.append(event)


# ── Session helpers (same logic as ground.py) ─────────────────────────────────

def _split_signed(data: bytes):
    _, _, t_id, a_id, tele_raw_len, tele_comp_len, audio_raw_len, audio_comp_len, audio_ext_b, sha = \
        struct.unpack_from(BUNDLE_FMT, data)
    bundle_end = BUNDLE_HDR_SZ + tele_comp_len + audio_comp_len
    if len(data) < bundle_end + 2:
        raise ValueError("Data truncated: cannot read signature length")
    sig_len = struct.unpack_from("!H", data, bundle_end)[0]
    bundle  = data[:bundle_end]
    sig     = data[bundle_end + 2: bundle_end + 2 + sig_len]
    return bundle, sig


def _calculate_bw(packet_list):
    valid = [p for p in packet_list if "recv_t" in p]
    if len(valid) < 2:
        return 0, 0
    dur   = valid[-1]["recv_t"] - valid[0]["recv_t"]
    total = sum(p["wire_bytes"] for p in valid)
    if dur > 0:
        return dur, (total * 8 / dur) / 1_000_000
    return 0, 0


def _try_fec(data_chunks, fec_parities, total, received):
    for grp_id, parity in list(fec_parities.items()):
        grp_start = grp_id * FEC_K
        grp_end   = min(grp_start + FEC_K, total)
        grp_idx   = list(range(grp_start, grp_end))
        present   = {i - grp_start: data_chunks[i] for i in grp_idx if i in data_chunks}
        missing   = [i for i in grp_idx if i not in data_chunks]
        if len(missing) == 1:
            try:
                recovered = fec_recover(present, len(grp_idx), parity)
                idx = missing[0]
                data_chunks[idx] = recovered
                received.add(idx)
                print(f"  [FEC] recovered chunk {idx} from group {grp_id} parity")
            except ValueError:
                pass


def _finalize_session(session_hex, data_chunks, total, pkt_log, gs_name, quic_meta):
    bundle = b"".join(data_chunks[i] for i in range(total))
    sid8   = session_hex[:8]
    print(f"\n  Reassembled {len(bundle):,}B")

    try:
        bundle_body, sig = _split_signed(bundle)
    except Exception as e:
        print(f"  ERROR parsing signed bundle: {e}")
        return

    payload_signed = bundle_body[BUNDLE_HDR_SZ:]

    try:
        pub_key = load_ecdsa_public()
    except FileNotFoundError:
        print("  ERROR: keys/aircraft_public.pem not found")
        return

    ecdsa_ok = ecdsa_verify(pub_key, payload_signed, sig)
    print(f"  ECDSA signature : {'[ok] VALID' if ecdsa_ok else '[fail] INVALID'}")
    if not ecdsa_ok:
        print("  Aborting — signature invalid")
        return

    try:
        result = decompress_bundle(bundle_body)
    except Exception as e:
        print(f"  Decompress failed: {e}")
        return

    time_taken, speed = _calculate_bw(pkt_log)
    tele       = result["tele"]
    audio      = result["audio"]
    tele_algo  = result["tele_algo"]
    audio_algo = result["audio_algo"]
    audio_ext  = result.get("audio_ext", ".wav")

    import compress
    adpcm_comp_len = len(compress.adpcm_encode(audio))

    print(f"  Telemetry Algorithm   : {tele_algo.upper()}")
    print(f"  Audio Algorithm       : {audio_algo.upper()}")
    print(f"  Telemetry             : {result['tele_raw_len']:,}B -> {result['tele_comp_len']:,}B")
    print(f"  Audio                 : {result['audio_raw_len']:,}B -> {adpcm_comp_len:,}B  [{audio_ext}]")
    print(f"  Transfer took         : {time_taken:.4f}s")
    print(f"  Average Bandwidth     : {speed:.2f} Mbps")

    # ── QUIC diagnostic summary ───────────────────────────────────────────────
    print(f"\n  ── QUIC Transport Diagnostics ──────────────────────────")
    print(f"  Protocol              : QUIC (RFC 9000)")
    print(f"  TLS version           : TLS 1.3  (AEAD per record)")
    print(f"  QUIC version          : {quic_meta.get('quic_version', 'negotiated')}")
    print(f"  TLS cipher            : {quic_meta.get('tls_cipher', 'TLS_AES_128_GCM_SHA256')}")
    print(f"  Streams used          : bundle(id=0)  ack(id=4)  meta(id=8)")
    print(f"  Per-pkt HMAC          : NOT NEEDED — TLS 1.3 AEAD covers integrity")
    print(f"  Encryption in transit : YES — TLS 1.3 encrypts every byte")
    print(f"  Packets received      : {len(pkt_log)}")
    lats = [p["latency_ms"] for p in pkt_log if p.get("latency_ms") is not None]
    if lats:
        print(f"  Avg latency           : {sum(lats)/len(lats):.1f}ms")
        print(f"  P95 latency           : {sorted(lats)[int(len(lats)*0.95)]:.1f}ms")
    print(f"  ────────────────────────────────────────────────────────")

    # emit a machine-readable QUIC summary line for the GUI to parse
    print(f"QUIC_PROTO:QUIC RFC9000|TLS1.3|{quic_meta.get('tls_cipher','TLS_AES_128_GCM_SHA256')}|streams=0,4,8|encrypted=YES")

    tele_path  = f"output/received/telemetry_{sid8}.bin"
    audio_path = f"output/received/audio_{sid8}{audio_ext}"
    os.makedirs("output/received", exist_ok=True)
    with open(tele_path, "wb") as f:
        f.write(tele)
    if audio_ext == ".wav":
        with wave.open(audio_path, "wb") as wf:
            wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(8000)
            wf.writeframes(audio)
    else:
        with open(audio_path, "wb") as f:
            f.write(audio)
    print(f"  Saved telemetry : {tele_path}")
    print(f"  Saved audio     : {audio_path}")

    # Compare vs original
    tele_match = audio_match = False
    if os.path.exists("output/telemetry_raw.bin"):
        orig_tele  = open("output/telemetry_raw.bin", "rb").read()
        tele_match = (tele == orig_tele)
        print(f"  Tele match orig : {'MATCH [ok]' if tele_match else 'MISMATCH [fail]'} "
              f"({len(tele):,}B vs {len(orig_tele):,}B)")

    orig_audio_path = f"cockpit_audio{audio_ext}"
    if os.path.exists(orig_audio_path):
        if audio_ext == ".flac":
            orig = open(orig_audio_path, "rb").read()
            audio_match = (audio == orig)
            print(f"  Audio match orig: {'MATCH [ok]' if audio_match else 'MISMATCH [fail]'} "
                  f"({len(audio):,}B vs {len(orig):,}B - Binary FLAC)")

    lats = [p["latency_ms"] for p in pkt_log if p.get("latency_ms") is not None]
    log  = {
        "gs_name":          gs_name,
        "session_id":       session_hex,
        "timestamp":        time.strftime("%Y-%m-%dT%H:%M:%S"),
        "transport":        "QUIC RFC9000 + TLS1.3",
        "quic_version":     quic_meta.get("quic_version", "1"),
        "tls_cipher":       quic_meta.get("tls_cipher", "TLS_AES_128_GCM_SHA256"),
        "total_chunks":     total,
        "received_chunks":  len(data_chunks),
        "ecdsa_valid":      ecdsa_ok,
        "tele_match_orig":  tele_match,
        "audio_match_orig": audio_match,
        "tele_algo":        tele_algo,
        "audio_algo":       audio_algo,
        "tele_raw_bytes":   result["tele_raw_len"],
        "audio_raw_bytes":  result["audio_raw_len"],
        "avg_latency_ms":   round(sum(lats)/len(lats), 1) if lats else None,
        "p95_latency_ms":   sorted(lats)[int(len(lats)*0.95)] if len(lats) > 1 else None,
        "packets":          pkt_log,
    }
    log_path = f"output/received/log_{sid8}_{gs_name}_quic.json"
    with open(log_path, "w") as f:
        json.dump(log, f, indent=2)
    print(f"  Log             : {log_path}")


# ── QUIC server handler ────────────────────────────────────────────────────────

class FDRGroundHandler(QuicConnectionProtocol):
    """One instance per QUIC connection (one aircraft)."""

    def __init__(self, *args, gs_name="GS-QUIC", once=False, **kwargs):
        super().__init__(*args, **kwargs)
        self._gs_name    = gs_name
        self._once       = once
        self._buf        = bytearray()       # reassembly buffer for stream 0
        self._ack_buf    = bytearray()

        # session state
        self._data_chunks  = {}
        self._fec_parities = {}
        self._received     = set()
        self._pkt_log      = []
        self._total        = None
        self._session_hex  = None
        self._quic_meta    = {}
        self._done         = False

    def quic_event_received(self, event):

        if isinstance(event, HandshakeCompleted):
            # Capture TLS 1.3 negotiated parameters
            self._quic_meta = {
                "quic_version": hex(self._quic._version),
                "tls_cipher":   getattr(self._quic.tls, "_cipher_suite", None)
                                or "TLS_AES_128_GCM_SHA256",
            }
            print(f"\n  [QUIC] Handshake complete — TLS 1.3 established")
            print(f"  [QUIC] QUIC version : {self._quic_meta['quic_version']}")
            print(f"  [QUIC] TLS cipher   : {self._quic_meta['tls_cipher']}")
            print(f"  [QUIC] All data from this point is ENCRYPTED + AUTHENTICATED by TLS 1.3")
            print(f"  [QUIC] No per-packet HMAC needed — AEAD handles it at record level")
            print(f"QUIC_HANDSHAKE:TLS1.3|{self._quic_meta['quic_version']}|{self._quic_meta['tls_cipher']}")

        elif isinstance(event, StreamDataReceived):
            if event.stream_id == 0:          # bundle stream
                self._handle_bundle_stream(event.data)
            # streams 4 and 8 are outbound (ACK, META) — ignore incoming

        elif isinstance(event, ConnectionTerminated):
            print(f"  [QUIC] Connection terminated: {event.error_code} {event.reason_phrase}")

    def _handle_bundle_stream(self, data: bytes):
        """
        QUIC delivers stream data in order but may deliver it in pieces.
        We frame messages with a 4-byte big-endian length prefix so we can
        reassemble partial deliveries.
        """
        self._buf.extend(data)

        while len(self._buf) >= 4:
            msg_len = struct.unpack_from("!I", self._buf, 0)[0]
            if len(self._buf) < 4 + msg_len:
                break                          # wait for more data
            msg = bytes(self._buf[4: 4 + msg_len])
            del self._buf[: 4 + msg_len]
            self._process_chunk_message(msg)

    def _process_chunk_message(self, data: bytes):
        recv_t = time.time()

        try:
            fields, payload = parse_packet(data)
        except ValueError as e:
            print(f"  [QUIC-REJECT] {e}")
            return

        sid_hex = fields["session"].hex()
        chunk   = fields["chunk"]
        tot     = fields["total"]
        flags   = fields["flags"]
        grp_id  = fields["fec_grp"]
        lat_ms  = round((recv_t - fields["ts_ms"] / 1000.0) * 1000, 1)

        if self._session_hex is None:
            self._session_hex = sid_hex
            self._total       = tot
            print(f"\n  [QUIC-NEW] session {sid_hex[:16]}  total={tot}")

        if flags & FLAG_PARITY:
            self._fec_parities[grp_id] = payload
            _try_fec(self._data_chunks, self._fec_parities, self._total, self._received)
        else:
            is_dup = chunk in self._received
            if not is_dup:
                self._data_chunks[chunk] = payload
                self._received.add(chunk)

            self._pkt_log.append({
                "chunk":      chunk,
                "seq":        fields["seq"],
                "ts_ms":      fields["ts_ms"],
                "recv_t":     round(recv_t, 4),
                "latency_ms": lat_ms,
                "wire_bytes": fields["wire_bytes"],
                "retx":       bool(flags & FLAG_RETX),
                "dup":        is_dup,
                "transport":  "QUIC",
            })
            tag = "DUP " if is_dup else "RECV"
            print(f"  [{tag}] chunk {chunk+1:>4}/{tot}  "
                  f"seq={fields['seq']:<5}  "
                  f"lat={lat_ms}ms  "
                  f"got={len(self._received)}/{tot}  "
                  f"[QUIC/TLS1.3]")

        if self._total:
            print(f"PROGRESS:{len(self._received)}:{self._total}", flush=True)

        # Emit bitmap ACK back on stream 4
        self._emit_acks()

        # Check completion
        if self._total and len(self._received) >= self._total and not self._done:
            self._done = True
            print(f"\n  {'-'*50}")
            print(f"  All {self._total} chunks received over QUIC.")
            _finalize_session(
                self._session_hex,
                self._data_chunks,
                self._total,
                self._pkt_log,
                self._gs_name,
                self._quic_meta,
            )
            print(f"  {'-'*50}\n")

    def _emit_acks(self):
        """Send bitmap ACKs on QUIC stream 4."""
        if self._total is None:
            return
        ack_frames = bytearray()
        for win_start in range(0, self._total, 64):
            bitmap = 0
            for bit in range(64):
                if (win_start + bit) in self._received:
                    bitmap |= (1 << bit)
            ack_msg = make_ack(win_start, bitmap)
            # frame: 4B length prefix + ack_msg
            ack_frames += struct.pack("!I", len(ack_msg)) + ack_msg

        self._quic.send_stream_data(ACK_STREAM_ID, bytes(ack_frames))
        self.transmit()

    def _emit_meta(self, event_dict: dict):
        """Send a JSON diagnostic event on QUIC stream 8."""
        line = (json.dumps(event_dict) + "\n").encode()
        msg  = struct.pack("!I", len(line)) + line
        self._quic.send_stream_data(META_STREAM_ID, msg)
        self.transmit()


def _make_handler(gs_name, once):
    """Factory so we can pass gs_name/once into protocol instances."""
    def _factory(*args, **kwargs):
        return FDRGroundHandler(*args, gs_name=gs_name, once=once, **kwargs)
    return _factory


# ── Entry point ────────────────────────────────────────────────────────────────

async def run_server(host, port, gs_name, once):
    config = QuicConfiguration(is_client=False)
    config.load_cert_chain(CERT_PATH, KEY_PATH)
    # QUIC enforces TLS 1.3 — no downgrade possible
    config.verify_mode = False   # self-signed; production: set CA bundle

    print(f"{'='*58}")
    print(f"  {gs_name}  —  QUIC server on udp:{port}")
    print(f"  Transport   : QUIC RFC 9000")
    print(f"  Security    : TLS 1.3  (AEAD — AES-128-GCM or CHACHA20)")
    print(f"  Certificate : {CERT_PATH}")
    print(f"  FEC         : XOR parity, {FEC_K} data + 1 parity / group")
    print(f"  Streams     : bundle=0  ack=4  meta=8")
    print(f"{'='*58}\n")

    await serve(
        host, port,
        configuration=config,
        create_protocol=_make_handler(gs_name, once),
    )
    await asyncio.Future()   # run forever


def main():
    ap = argparse.ArgumentParser(description="Ground station receiver — QUIC transport")
    ap.add_argument("--host",   default="0.0.0.0")
    ap.add_argument("--port",   type=int, default=9010)
    ap.add_argument("--name",   default="GS-QUIC-Primary")
    ap.add_argument("--once",   action="store_true")
    args = ap.parse_args()

    if not os.path.exists(CERT_PATH) or not os.path.exists(KEY_PATH):
        print(f"ERROR: TLS certs not found. Run:  python gen_certs.py")
        sys.exit(1)

    try:
        asyncio.run(run_server(args.host, args.port, args.name, args.once))
    except KeyboardInterrupt:
        print(f"\n{args.name} stopped.")


if __name__ == "__main__":
    main()
