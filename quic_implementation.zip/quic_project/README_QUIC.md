# FDR/CVR QUIC Implementation — Run Guide

## What's new vs the original codebase

| File | Status | What changed |
|---|---|---|
| `gen_certs.py` | **NEW** | Generates TLS 1.3 self-signed cert for QUIC |
| `protocol_quic.py` | **NEW** | QUIC wire format (no HMAC, slimmer header, stream IDs) |
| `aircraft_quic.py` | **NEW** | Aircraft sender over QUIC (async, aioquic) |
| `ground_quic.py` | **NEW** | Ground receiver over QUIC (async, aioquic server) |
| `gui_quic.py` | **NEW** | Aircraft GUI — identical to gui.py + QUIC panel |
| `gnd_gui3_quic.py` | **NEW** | Ground GUI — identical to gnd_gui3.py + QUIC panel |
| `config.py` | **UPDATED** | +2 lines: QUIC_CERT_PATH, QUIC_KEY_PATH, QUIC_GROUND_STATIONS |
| All other files | **UNCHANGED** | compress.py, crypto.py, telemetry.py, keys.py, protocol.py, aircraft.py, ground.py, gui.py, gnd_gui3.py |

---

## Step 0 — Install dependencies (once)

```bash
pip install aioquic cryptography
# If you also need audio:
pip install sounddevice soundfile numpy
```

---

## Step 1 — Generate TLS 1.3 certificates (once)

```bash
python gen_certs.py
```

Expected output:
```
[CERTS] Generated TLS 1.3 certificate for QUIC:
  Certificate : certs/quic_cert.pem
  Private key : certs/quic_key.pem
  Valid until : 2036-xx-xx
  SAN         : localhost / 127.0.0.1
```

---

## Option A — Run with GUIs (recommended)

Open **two terminals** in the project folder.

**Terminal 1 — Ground GUI:**
```bash
python gnd_gui3_quic.py
```
- Login: `Shubham` / `1234`
- Click **Ground Active**
- Watch the ⚡ QUIC Transport panel populate as the handshake completes

**Terminal 2 — Aircraft GUI:**
```bash
python gui_quic.py
```
- Login: `Sushil` / `0987`
- Click **Start Transmission**
- Watch the ⚡ QUIC Transport panel show TLS version, cipher, and encryption status

---

## Option B — Run headless (no GUI, command line only)

Open **4 terminals** (or run in background with `&`).

**Terminal 1 — Ground Primary:**
```bash
python ground_quic.py --port 9010 --name GS-QUIC-Primary
```

**Terminal 2 — Ground Backup (optional):**
```bash
python ground_quic.py --port 9011 --name GS-QUIC-Backup
```

**Terminal 3 — Ground Charlie (optional):**
```bash
python ground_quic.py --port 9012 --name GS-QUIC-Charlie
```

**Terminal 4 — Aircraft sender:**
```bash
python aircraft_quic.py
```

With a custom audio file:
```bash
python aircraft_quic.py --audio /path/to/cockpit_audio.flac
python aircraft_quic.py --audio /path/to/recording.wav
```

---

## What you'll see in the logs

### Ground station startup:
```
==========================================================
  GS-QUIC-Primary  —  QUIC server on udp:9010
  Transport   : QUIC RFC 9000
  Security    : TLS 1.3  (AEAD — AES-128-GCM or CHACHA20)
  Certificate : certs/quic_cert.pem
  FEC         : XOR parity, 8 data + 1 parity / group
  Streams     : bundle=0  ack=4  meta=8
==========================================================
```

### After aircraft connects (ground side):
```
  [QUIC] Handshake complete — TLS 1.3 established
  [QUIC] QUIC version : 0xff00001d
  [QUIC] TLS cipher   : TLS_AES_128_GCM_SHA256
  [QUIC] All data from this point is ENCRYPTED + AUTHENTICATED by TLS 1.3
  [QUIC] No per-packet HMAC needed — AEAD handles it at record level

QUIC_HANDSHAKE:TLS1.3|0xff00001d|TLS_AES_128_GCM_SHA256   ← GUI reads this
```

### Aircraft sender handshake:
```
  [QUIC-CLIENT] Handshake complete with ground station
  [QUIC-CLIENT] Version : 0xff00001d
  [QUIC-CLIENT] Cipher  : TLS_AES_128_GCM_SHA256
  [QUIC-CLIENT] All transmission is TLS 1.3 encrypted from here

QUIC_HANDSHAKE:TLS1.3|0xff00001d|TLS_AES_128_GCM_SHA256   ← GUI reads this
```

### Chunk transmission:
```
  [SENT] t=1.2s  chunk    1/142  seq=1    retry=0  acked=0/142  [QUIC/TLS1.3]
  [SENT] t=1.2s  chunk    2/142  seq=2    retry=0  acked=0/142  [QUIC/TLS1.3]
  ...
  [BLACKOUT] chunk 23 dropped (ends in 8.4s)      ← NetworkSim still fires
  [RETX] t=22.1s chunk   23/142  seq=145  retry=1  acked=141/142  [QUIC/TLS1.3]
```

### Ground reception:
```
  [RECV] chunk    1/ 142  seq=1    lat=42.3ms  got=1/142  [QUIC/TLS1.3]
  [RECV] chunk    2/ 142  seq=2    lat=41.8ms  got=2/142  [QUIC/TLS1.3]
  ...
PROGRESS:142:142      ← GUI progress bar reads this
```

### Ground finalization (QUIC diagnostics section):
```
  ── QUIC Transport Diagnostics ──────────────────────────
  Protocol              : QUIC (RFC 9000)
  TLS version           : TLS 1.3  (AEAD per record)
  QUIC version          : 0xff00001d
  TLS cipher            : TLS_AES_128_GCM_SHA256
  Streams used          : bundle(id=0)  ack(id=4)  meta(id=8)
  Per-pkt HMAC          : NOT NEEDED — TLS 1.3 AEAD covers integrity
  Encryption in transit : YES — TLS 1.3 encrypts every byte
  Packets received      : 142
  Avg latency           : 43.1ms
  P95 latency           : 51.2ms
  ────────────────────────────────────────────────────────

QUIC_PROTO:QUIC RFC9000|TLS1.3|TLS_AES_128_GCM_SHA256|streams=0,4,8|encrypted=YES
```

### Log file saved:
```
output/received/log_<session>_GS-QUIC-Primary_quic.json
```
This JSON contains: transport, quic_version, tls_cipher, ecdsa_valid,
tele_match_orig, audio_match_orig, avg_latency_ms, p95_latency_ms, per-packet log.

---

## QUIC vs UDP — key differences you'll observe

| What | Original UDP | QUIC |
|---|---|---|
| Handshake log | None | `[QUIC] Handshake complete — TLS 1.3` printed before any data |
| Per-packet HMAC | `32B HMAC appended to every pkt` | `NOT NEEDED — TLS 1.3 AEAD` |
| Encryption | Plaintext payload | `YES — TLS 1.3 encrypts every byte` |
| Chunk tag | `[SENT]` / `[RECV]` | `[SENT] … [QUIC/TLS1.3]` / `[RECV] … [QUIC/TLS1.3]` |
| Log filename | `log_*_GS-Primary.json` | `log_*_GS-QUIC-Primary_quic.json` |
| GUI panel | None | ⚡ QUIC Transport panel with live cipher/version/latency |

---

## File tree after running

```
project/
├── certs/
│   ├── quic_cert.pem          ← TLS 1.3 certificate (created by gen_certs.py)
│   └── quic_key.pem           ← TLS 1.3 private key
├── keys/
│   ├── aircraft_private.pem   ← ECDSA signing key
│   └── aircraft_public.pem    ← ECDSA verification key
├── output/
│   ├── bundle_signed_quic.bin ← signed+compressed bundle
│   └── received/
│       ├── telemetry_<id>.bin
│       ├── audio_<id>.flac
│       └── log_<id>_GS-QUIC-Primary_quic.json   ← QUIC diagnostics
├── gen_certs.py       ← NEW
├── protocol_quic.py   ← NEW
├── aircraft_quic.py   ← NEW
├── ground_quic.py     ← NEW
├── gui_quic.py        ← NEW
├── gnd_gui3_quic.py   ← NEW
├── config.py          ← UPDATED (+3 QUIC lines)
└── [all original files unchanged]
```

---

## Troubleshooting

**`ERROR: TLS certs not found`**
→ Run `python gen_certs.py` first.

**`Could not connect to GS-QUIC-Primary`**
→ Start `ground_quic.py` before `aircraft_quic.py`.

**`aioquic not found`**
→ Run `pip install aioquic`.

**Audio path errors**
→ Set `CVR_AUDIO_PATH = None` in `config.py` to use synthetic audio,
  or pass `--audio yourfile.flac` on the command line.

**GUI doesn't show QUIC panel updating**
→ The panel updates only after the QUIC handshake completes.
  Make sure the ground GUI is started and active before the aircraft GUI.
