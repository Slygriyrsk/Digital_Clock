"""
protocol_quic.py — Wire format for QUIC transport.

What changes vs protocol.py:
  - No UDP socket management (QUIC handles that)
  - No HMAC per-packet (QUIC/TLS-1.3 provides authenticated encryption per frame)
  - Packet header is slimmer: no HMAC_SZ tail, no pay_len (stream framing handles it)
  - FEC parity, bitmap ACK, chunk/total indexing: ALL KEPT IDENTICAL
  - BUNDLE_STREAM_ID = 0  : aircraft → ground (FDR bundle chunks)
  - ACK_STREAM_ID    = 4  : ground → aircraft (bitmap ACKs)
  - META_STREAM_ID   = 8  : ground → aircraft (QUIC diagnostic metadata)

Packet wire layout (QUIC stream payload, per chunk message):
  [4B]  magic    b"FDRQ"   (Q = QUIC variant)
  [16B] session  UUID bytes
  [4B]  seq      uint32 monotonic
  [2B]  chunk    uint16 index within bundle (0-based)
  [2B]  total    uint16 total data chunks
  [1B]  flags    bit0=FEC_PARITY, bit1=RETRANSMIT
  [4B]  fec_grp  uint32
  [8B]  ts_ms    uint64 sender wall-clock ms
  [2B]  pay_len  uint16
  [N B] payload                     ← no HMAC tail (TLS 1.3 covers this)

Bitmap ACK layout (ground → aircraft, same as before):
  [4B]  magic    b"BACK"
  [2B]  win_start uint16
  [8B]  bitmap   uint64

QUIC Diagnostic meta message (ground → aircraft, stream 8):
  JSON line, newline-terminated.
  Fields: event, stream_id, chunk, total, lat_ms, recv_t, quic_version, tls_cipher
"""

import struct
import time

# Stream IDs (QUIC client-initiated bidirectional: 0, 4, 8 ...)
BUNDLE_STREAM_ID = 0
ACK_STREAM_ID    = 4
META_STREAM_ID   = 8

# Packet header (no HMAC — TLS 1.3 inside QUIC handles integrity+confidentiality)
PKT_MAGIC   = b"FDRQ"
PKT_FMT     = "!4s16sIHHBIQH"
PKT_HDR_SZ  = struct.calcsize(PKT_FMT)

# Bitmap ACK (identical to protocol.py)
ACK_MAGIC   = b"BACK"
ACK_FMT     = "!4sHQ"
ACK_SZ      = struct.calcsize(ACK_FMT)

# Flags (identical to protocol.py)
FLAG_PARITY = 0x01
FLAG_RETX   = 0x02

# FEC group size (identical to protocol.py)
FEC_K       = 8


def make_packet(session: bytes, seq: int, chunk: int, total: int,
                payload: bytes, flags: int = 0, fec_grp: int = 0) -> bytes:
    """
    Build a QUIC stream chunk message.
    No HMAC appended — QUIC/TLS-1.3 provides AEAD per record.
    """
    ts_ms  = int(time.time() * 1000)
    header = struct.pack(PKT_FMT, PKT_MAGIC, session, seq,
                         chunk, total, flags, fec_grp, ts_ms, len(payload))
    return header + payload


def parse_packet(data: bytes):
    """
    Parse a QUIC stream chunk message.
    Returns (fields_dict, payload) or raises ValueError.
    No HMAC check here — TLS 1.3 already verified the record.
    """
    if len(data) < PKT_HDR_SZ:
        raise ValueError(f"Packet too short: {len(data)} < {PKT_HDR_SZ}")

    magic, session, seq, chunk, total, flags, fec_grp, ts_ms, pay_len = \
        struct.unpack_from(PKT_FMT, data)

    if magic != PKT_MAGIC:
        raise ValueError(f"Bad magic: {magic!r}")

    payload = data[PKT_HDR_SZ : PKT_HDR_SZ + pay_len]
    if len(payload) < pay_len:
        raise ValueError("Truncated payload")

    return {
        "session":    session,
        "seq":        seq,
        "chunk":      chunk,
        "total":      total,
        "flags":      flags,
        "fec_grp":    fec_grp,
        "ts_ms":      ts_ms,
        "wire_bytes": len(data),
    }, payload


def make_ack(win_start: int, bitmap: int) -> bytes:
    """Bitmap ACK — identical wire format to protocol.py."""
    return struct.pack(ACK_FMT, ACK_MAGIC, win_start, bitmap)


def parse_ack(data: bytes):
    """Return (win_start, bitmap) or raise ValueError."""
    if len(data) < ACK_SZ or data[:4] != ACK_MAGIC:
        raise ValueError("Bad ACK")
    _, win_start, bitmap = struct.unpack_from(ACK_FMT, data)
    return win_start, bitmap


def fec_parity(group_payloads: list) -> bytes:
    """XOR parity — identical to protocol.py."""
    max_len = max(len(p) for p in group_payloads)
    result  = bytearray(max_len)
    for p in group_payloads:
        padded = p + bytes(max_len - len(p))
        for i in range(max_len):
            result[i] ^= padded[i]
    return bytes(result)


def fec_recover(group_payloads: dict, total_in_group: int, parity: bytes) -> bytes:
    """Single-erasure XOR recovery — identical to protocol.py."""
    present = set(group_payloads.keys())
    missing = set(range(total_in_group)) - present
    if len(missing) != 1:
        raise ValueError(f"FEC can only recover 1 erasure, {len(missing)} missing")
    result = bytearray(parity)
    for p in group_payloads.values():
        padded = p + bytes(len(result) - len(p))
        for i in range(len(result)):
            result[i] ^= padded[i]
    return bytes(result)
