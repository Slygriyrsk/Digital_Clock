"""
gnd_gui3_quic.py  —  Ground-station GUI  (QUIC variant)

IDENTICAL to gnd_gui3.py in every widget, layout, credential, and behaviour.
Two additions only:
  1. Launches ground_quic.py instead of ground.py
  2. Small "QUIC Transport" panel below the Session Summary showing:
       • Handshake status   • TLS version / cipher
       • Encryption status  • Streams used
       • Avg latency P95    • Per-pkt HMAC status
     All fields update live from stdout parsing of ground_quic.py.
"""

import os
import sys
import glob
import struct
import subprocess
import threading
import tkinter as tk
from tkinter import messagebox, ttk

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

import compress  as comp
import telemetry as tele
import config    as cfg

try:
    import sounddevice as sd
    import soundfile   as sf
    _AUDIO_OK = True
except ImportError:
    _AUDIO_OK = False

active_session = None
metric_labels  = {}


# ── Audio playback (identical to gnd_gui3.py) ────────────────────────────────

def play_received_audio():
    if not _AUDIO_OK:
        messagebox.showwarning("No audio", "sounddevice / soundfile not installed.")
        return
    found = glob.glob("output/received/audio_*.flac")
    if not found:
        messagebox.showwarning("No File", "No received audio found.")
        return
    path = found[-1]
    try:
        mb = os.path.getsize(path) / 1048576
        print(f"Playing: {path} ({mb:.2f} MB)")
        root.after(0, lambda: metric_labels["audio_size"].config(
            text=f"{mb:.2f} MB", fg="darkgreen"))
        data, fs = sf.read(path)
        sd.play(data, fs)
    except Exception as e:
        messagebox.showerror("Error", f"Could not play audio: {e}")


def stop_received_audio():
    if _AUDIO_OK:
        sd.stop()
    print("Audio playback killed.")


# ── stdout reader (parses QUIC-specific lines too) ───────────────────────────

def read_subprocess_output(process):
    try:
        while True:
            line = process.stdout.readline()
            if not line:
                break
            s = line.decode("utf-8", errors="replace").strip()
            print(s)
            cl = s.lower().strip()

            # ── original metrics (identical to gnd_gui3.py) ──
            if "telemetry algorithm" in cl:
                v = s.split(":", 1)[1].strip() if ":" in s else s
                root.after(0, lambda v=v: metric_labels["tele_algo"].config(
                    text=v, fg="darkgreen"))

            elif "audio algorithm" in cl:
                v = s.split(":", 1)[1].strip() if ":" in s else s
                root.after(0, lambda v=v: metric_labels["audio_algo"].config(
                    text=v, fg="darkgreen"))

            elif cl.startswith("telemetry") and "->" in cl:
                v = s.split(":", 1)[1].strip() if ":" in s else s
                root.after(0, lambda v=v: metric_labels["tele_size"].config(
                    text=v, fg="blue"))

            elif cl.startswith("audio") and "->" in cl:
                v = s.split(":", 1)[1].strip() if ":" in s else s
                root.after(0, lambda v=v: metric_labels["audio_size"].config(
                    text=v, fg="blue"))

            elif "average bandwidth:" in cl:
                v = s.replace("Average Bandwidth:", "").strip()
                root.after(0, lambda v=v: metric_labels["bandwidth"].config(
                    text=v, fg="magenta"))

            # ── QUIC handshake line ──
            # Format:  QUIC_HANDSHAKE:TLS1.3|0x1|TLS_AES_128_GCM_SHA256
            if s.startswith("QUIC_HANDSHAKE:"):
                parts  = s[len("QUIC_HANDSHAKE:"):].split("|")
                tls_v  = parts[0] if len(parts) > 0 else "TLS1.3"
                qver   = parts[1] if len(parts) > 1 else "—"
                cipher = parts[2] if len(parts) > 2 else "—"
                root.after(0, lambda v=tls_v:  _q["tls"].config(text=v,    fg="#006600"))
                root.after(0, lambda v=qver:   _q["ver"].config(text=v,    fg="#006600"))
                root.after(0, lambda v=cipher: _q["cip"].config(text=v,    fg="#006600"))
                root.after(0, lambda:          _q["enc"].config(
                    text="✔ ALL DATA ENCRYPTED", fg="#006600"))
                root.after(0, lambda:          _q["hmac"].config(
                    text="Not needed — TLS 1.3 AEAD", fg="gray"))
                root.after(0, lambda:          _q["hs"].config(
                    text="✔ Complete", fg="#006600"))

            # ── QUIC proto summary line ──
            # Format: QUIC_PROTO:QUIC RFC9000|TLS1.3|cipher|streams=0,4,8|encrypted=YES
            if s.startswith("QUIC_PROTO:"):
                rest   = s[len("QUIC_PROTO:"):]
                parts  = rest.split("|")
                proto  = parts[0] if len(parts) > 0 else "QUIC"
                strms  = next((p for p in parts if p.startswith("streams=")), "0,4,8")
                root.after(0, lambda v=proto: _q["proto"].config(text=v, fg="#006600"))
                root.after(0, lambda v=strms: _q["strms"].config(
                    text=v.replace("streams=", ""), fg="#006600"))

            # ── avg/P95 latency ──
            if "avg latency" in cl and "ms" in cl:
                v = s.split(":")[-1].strip()
                root.after(0, lambda v=v: _q["lat"].config(text=v, fg="#555"))

            if "p95 latency" in cl and "ms" in cl:
                v = s.split(":")[-1].strip()
                root.after(0, lambda v=v: _q["p95"].config(text=v, fg="#555"))

            # ── progress bar ──
            if s.startswith("PROGRESS:"):
                _, cur, tot = s.split(":")
                cur, tot = int(cur), int(tot)
                root.after(0, update_progress, cur, tot)
                if cur >= tot > 0:
                    root.after(100, regenerate_and_plot)

            elif "all" in cl and "chunks received" in cl:
                root.after(0, lambda: status_label.config(
                    text="Status: Transfer Complete! [ok]", fg="green"))
                root.after(100, regenerate_and_plot)

            elif "audio match orig:" in cl:
                root.after(0, lambda: status_label.config(
                    text="Status: Verified Lossless Match [ok]", fg="darkgreen"))

    except Exception as e:
        print(f"Error reading process output: {e}")


def update_progress(current, total):
    progress_bar["maximum"] = total
    progress_bar["value"]   = current
    pct = (current / total * 100) if total > 0 else 0
    status_label.config(
        text=f"Status: Receiving Chunks ({current}/{total}) - {pct:.1f}%  [QUIC]",
        fg="blue")


# ── Telemetry regen / plot (identical to gnd_gui3.py) ────────────────────────

def regen_generation():
    rows = []
    for p in tele.PARAMS:
        name, rate_hz, wf, lo = p[0], p[1], p[2], p[3]
        hi = p[4] if len(p) > 4 else 100.0
        samples = tele._generate(name, rate_hz, wf, lo, hi, cfg.DURATION_SEC)
        rows.append((name, rate_hz, wf, lo, hi, samples, []))
    return rows


def regen_plot_data(rows):
    fig.clear()
    plottable = rows[:5]
    n = len(plottable)
    if n == 0:
        canvas.draw(); return
    subplots = fig.subplots(n, 1, sharex=True)
    fig.tight_layout(pad=1.5)
    for i, row in enumerate(plottable):
        name, _, _, lo, hi, samples, _ = row
        ax = subplots[i] if n > 1 else subplots
        ax.plot(samples, color=f"C{i}", linewidth=1.2)
        ax.set_title(f"Plot: {name}", fontsize=9, loc="left", pad=4)
        ax.set_ylabel(name[:12] + "…", fontsize=8, rotation=0, labelpad=35, ha="right")
        ax.set_ylim(lo - abs(lo)*0.1 if lo != 0 else -1,
                    hi + abs(hi)*0.1 if hi != 0 else 1)
        ax.grid(True, linestyle="--", alpha=0.5)
    canvas.draw()


def regenerate_and_plot():
    try:
        rows = regen_generation()
        regen_plot_data(rows)
        status_label.config(
            text="Status: Displaying regenerated telemetry [sim]", fg="darkgreen")
    except Exception as e:
        messagebox.showerror("Error", f"Could not regenerate/plot: {e}")


# ── Ground station launch ─────────────────────────────────────────────────────

def ground_primary_quic():
    return subprocess.Popen(
        [sys.executable, "-u", "ground_quic.py",
         "--port", str(cfg.GROUND_STATIONS[0]["port"] + 10),   # 9010
         "--name", "GS-QUIC-Primary"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )


def ground_backup_quic():
    return subprocess.Popen(
        [sys.executable, "-u", "ground_quic.py",
         "--port", str(cfg.GROUND_STATIONS[1]["port"] + 10),   # 9011
         "--name", "GS-QUIC-Backup"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )


def check_gnd_availability():
    global active_session
    if active_session is not None:
        status = active_session.poll()
        if status is not None:
            if status != 0:
                messagebox.showwarning(
                    "Failure", "Primary Down — Switching to QUIC Backup!")
                active_session = ground_backup_quic()
                threading.Thread(target=read_subprocess_output,
                                 args=(active_session,), daemon=True).start()
            else:
                messagebox.showinfo("Status", "Primary closed normally")
                active_session = None
        else:
            root.after(1000, check_gnd_availability)


def warning_pop():
    messagebox.showwarning("Not Authorized!", "Please give correct credentials")


def clear_metrics_dashboard():
    for lbl in metric_labels.values():
        lbl.config(text="--", fg="blue")
    for lbl in _q.values():
        lbl.config(text="—", fg="#888")


def ground_helper():
    global active_session
    username = entry1.get().strip()
    password = entry2.get().strip()

    if username == "Shubham" and password == "1234":
        try:
            clear_metrics_dashboard()
            active_session = ground_primary_quic()
            messagebox.showinfo("Status", "QUIC ground station active…")
            threading.Thread(target=read_subprocess_output,
                             args=(active_session,), daemon=True).start()
            status_label.config(
                text="Status: Connected. Listening for QUIC aircraft…", fg="orange")
            check_gnd_availability()
        except FileNotFoundError:
            messagebox.showerror("Error", "ground_quic.py not found.")
        except Exception as e:
            messagebox.showwarning("Primary Failed",
                                   f"{e}. Starting QUIC Backup.")
            active_session = ground_backup_quic()
            threading.Thread(target=read_subprocess_output,
                             args=(active_session,), daemon=True).start()
    else:
        warning_pop()


# ── GUI build ─────────────────────────────────────────────────────────────────

root = tk.Tk()
root.title("Client  [QUIC]")
root.geometry("1100x680")

control_frame = tk.Frame(root, padx=15, pady=15)
control_frame.pack(side=tk.LEFT, fill=tk.Y)

tk.Label(control_frame, text="Ground System  [QUIC]",
         font=("Arial", 10, "bold")).grid(row=0, column=0, columnspan=2, pady=10)

tk.Label(control_frame, text="Ground User ").grid(row=1, column=0, padx=10, pady=5)
entry1 = tk.Entry(control_frame)
entry1.grid(row=1, column=1, padx=10, pady=5)

tk.Label(control_frame, text="Password ").grid(row=2, column=0, padx=10, pady=5)
entry2 = tk.Entry(control_frame, show="*")
entry2.grid(row=2, column=1, padx=10, pady=5)

tk.Button(control_frame, text="Ground Active", width=25,
          command=ground_helper).grid(row=3, column=0, padx=10, pady=10)
tk.Button(control_frame, text="Ground Not Active", width=25,
          command=root.destroy).grid(row=3, column=1, padx=10, pady=10)

tk.Button(control_frame, text="▶️ Play Received Audio", width=25,
          command=play_received_audio).grid(row=4, column=0, padx=10, pady=5)
tk.Button(control_frame, text="⏹️ Stop Playback", width=25,
          command=stop_received_audio).grid(row=4, column=1, padx=10, pady=5)

status_label = tk.Label(control_frame,
                         text="Status: Disconnected / Idle",
                         font=("Arial", 10), fg="gray")
status_label.grid(row=5, column=0, columnspan=2, pady=5, sticky=tk.W)

progress_bar = ttk.Progressbar(control_frame, orient="horizontal",
                                length=380, mode="determinate")
progress_bar.grid(row=6, column=0, columnspan=2, pady=5, padx=10)

# ── Session Summary (identical to gnd_gui3.py) ────────────────────────────────
metrics_frame = tk.LabelFrame(control_frame, text="Session Summary",
                               font=("Arial", 10, "bold"),
                               bg="white", padx=12, pady=10)
metrics_frame.grid(row=7, column=0, columnspan=2,
                   pady=(10, 4), padx=10, sticky="ew")


def build_dashboard_row(label_text, dict_key, row_idx):
    tk.Label(metrics_frame, text=label_text,
             font=("Arial", 9), anchor="w").grid(row=row_idx, column=0,
                                                  sticky="w", pady=2)
    val = tk.Label(metrics_frame, text="--",
                   font=("Arial", 9, "bold"), fg="blue", anchor="e")
    val.grid(row=row_idx, column=1, sticky="e", pady=2)
    metrics_frame.grid_columnconfigure(1, weight=1)
    metric_labels[dict_key] = val


build_dashboard_row("Telemetry Algo:",  "tele_algo",  0)
build_dashboard_row("Telemetry Size:",  "tele_size",  1)
build_dashboard_row("Audio Algo:",      "audio_algo", 2)
build_dashboard_row("Audio Size:",      "audio_size", 3)
build_dashboard_row("Avg BW:",          "bandwidth",  4)

# ── QUIC Transport panel (the only addition vs gnd_gui3.py) ───────────────────
quic_frame = tk.LabelFrame(control_frame, text="⚡ QUIC Transport",
                            font=("Arial", 9, "bold"),
                            bg="#f0f8ff", padx=10, pady=6)
quic_frame.grid(row=8, column=0, columnspan=2,
                pady=(4, 6), padx=10, sticky="ew")


def _qrow(label, key, row):
    tk.Label(quic_frame, text=label, font=("Arial", 8),
             bg="#f0f8ff", anchor="w").grid(row=row, column=0, sticky="w")
    v = tk.Label(quic_frame, text="—", font=("Arial", 8, "bold"),
                 fg="#888", bg="#f0f8ff", anchor="w")
    v.grid(row=row, column=1, sticky="w", padx=(6, 0))
    quic_frame.grid_columnconfigure(1, weight=1)
    return v


_q = {}
_q["hs"]    = _qrow("Handshake:",        "hs",    0)
_q["tls"]   = _qrow("TLS version:",      "tls",   1)
_q["ver"]   = _qrow("QUIC version:",     "ver",   2)
_q["cip"]   = _qrow("Cipher:",           "cip",   3)
_q["enc"]   = _qrow("In-flight data:",   "enc",   4)
_q["hmac"]  = _qrow("Per-pkt HMAC:",     "hmac",  5)
_q["proto"] = _qrow("Protocol:",         "proto", 6)
_q["strms"] = _qrow("Streams:",          "strms", 7)
_q["lat"]   = _qrow("Avg latency:",      "lat",   8)
_q["p95"]   = _qrow("P95 latency:",      "p95",   9)

# ── Plot area (identical to gnd_gui3.py) ─────────────────────────────────────

visual_frame = tk.Frame(root, bg="white", padx=10, pady=10)
visual_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

fig    = Figure(figsize=(7, 4), dpi=100)
canvas = FigureCanvasTkAgg(fig, master=visual_frame)
canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

root.mainloop()
