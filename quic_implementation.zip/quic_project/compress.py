import hashlib
import struct
import time
import zlib
import bz2
import lzma
import audioop

# Header: magic(8) + session_id(16) + tele_algo(1) + audio_algo(1) + 
# tele_raw_len(4) + tele_comp_len(4) + audio_raw_len(4) + audio_comp_len(4) + 
# ext(4) + sha256(32) = 78 bytes
BUNDLE_MAGIC  = b"FDRBNDL5"
#BUNDLE_FMT    = "!8s16sBBIIII4s32s"  #4s is for .wav but for .flac 5s
BUNDLE_FMT = "!8s32sBBIIII5s32s" 
BUNDLE_HDR_SZ = struct.calcsize(BUNDLE_FMT)

# Telemetry Algorithms (Data-focused)
TELE_ALGOS = {
    "zlib":    (1, lambda d: zlib.compress(d, 9), zlib.decompress),
    "bz2":     (2, lambda d: bz2.compress(d, 9),  bz2.decompress),
    "lzma":    (3, lzma.compress,                  lzma.decompress),
}

# Audio Algorithms (Audio-focused)
# Note: Currently using 'passthrough' for PCM (.wav), 
# but you can swap these for actual codecs like ADPCM or FLAC.

def adpcm_encode(d):
    # ADPCM requires an even number of bytes for 16-bit (2-byte) samples
    if len(d) % 2 != 0:
        d += b'\x00'
    # audioop.lin2adpcm returns (adpcm_data, final_state)
    # We only want the data [0]
    return audioop.lin2adpcm(d, 2, None)[0]

def adpcm_decode(d):
    # audioop.adpcm2lin returns (pcm_data, final_state)
    return audioop.adpcm2lin(d, 2, None)[0]

AUDIO_ALGOS = {
    "pcm_raw": (1, lambda d: d, lambda d: d),
    "adpcm":   (2, adpcm_encode, adpcm_decode), 
}

# def compress_bundle(session_id: bytes, tele_raw: bytes, audio_raw: bytes, 
#                     audio_ext: str = ".wav") -> bytes:
    
#     #compress telemetry, pick the best
#     tele_results = []
#     for name, (id_val, cfn, dfn) in TELE_ALGOS.items():
#         t0 = time.perf_counter()
#         tc = cfn(tele_raw)
#         elapsed = (time.perf_counter() - t0) * 1000
        
#         # Check integrity
#         if dfn(tc) == tele_raw:
#             tele_results.append({
#                 "name": name, "id": id_val, "data": tc, "ms": elapsed
#             })
    
#     best_tele = min(tele_results, key=lambda x: len(x["data"]))
#     tc = best_tele["data"]
    
#     #compress audio
#     audio_algo_name = "pcm_raw" #or "pcm_raw" or "adpcm"
#     a_id, a_cfn, _ = AUDIO_ALGOS[audio_algo_name]
#     ac = a_cfn(audio_raw)

#     display_format = "FLAC_PASSTHROUGH" if audio_ext.lower() == ".flac" else audio_algo_name.upper()
    
#     print(f"FDR:   Selected {best_tele['name'].upper()} ({len(tele_raw):,} -> {len(tc):,} bytes)")
#     print(f"Audio: Selected {display_format} ({len(audio_raw):,} -> {len(ac):,} bytes)")

#     # 3. BUILD BUNDLE
#     #ext_b     = audio_ext.encode()[:4].ljust(4, b"\x00") #this is for .wav
#     ext_b     = audio_ext.encode()[:5].ljust(5, b"\x00") #this is for .flac
#     integrity = hashlib.sha256(tc + ac).digest()
    
#     header = struct.pack(BUNDLE_FMT,
#         BUNDLE_MAGIC, session_id, 
#         best_tele["id"], a_id,           # Separate IDs for Tele and Audio
#         len(tele_raw), len(tc), 
#         len(audio_raw), len(ac), 
#         ext_b, integrity)
    
#     print("AIRCRAFT HEADER:",
#       "magic=", BUNDLE_MAGIC,
#       "session_id=", session_id.hex(),
#       "tele_algo_id=", best_tele["id"],
#       "tele_raw_len=", len(tele_raw),
#       "tele_comp_len=", len(tc),
#       "audio_algo_id=", a_id,
#       "audio_raw_len=", len(audio_raw),
#       "audio_comp_len=", len(ac),
#       "audio_ext=", ext_b.rstrip(b'\\x00').decode(errors='ignore'))

#     return header + tc + ac

def compress_bundle(session_id: bytes, tele_raw: bytes, audio_raw: bytes, 
                    audio_ext: str = ".wav") -> tuple[bytes, list]:
    
    # 1. COMPRESS TELEMETRY (Pick best of competition)
    tele_results = []
    for name, (id_val, cfn, dfn) in TELE_ALGOS.items():
        t0 = time.perf_counter()
        tc_temp = cfn(tele_raw)
        elapsed = (time.perf_counter() - t0) * 1000 # msec
        
        ratio = len(tele_raw) / len(tc_temp) if len(tc_temp) > 0 else 1.0
        
        if dfn(tc_temp) == tele_raw:
            tele_results.append({
                "name": name, 
                "id": id_val, 
                "data": tc_temp, 
                "ms": elapsed,
                "ratio": ratio
            })
    
    best_tele = min(tele_results, key=lambda x: len(x["data"]))
    tc = best_tele["data"]
    
    audio_algo_name = "pcm_raw" 
    a_id, a_cfn, _ = AUDIO_ALGOS[audio_algo_name]
    ac = a_cfn(audio_raw)

    display_format = "FLAC_PASSTHROUGH" if audio_ext.lower() == ".flac" else audio_algo_name.upper()
    
    print(f"FDR:   Selected {best_tele['name'].upper()} ({len(tele_raw):,} -> {len(tc):,} bytes)")
    print(f"Audio: Selected {display_format} ({len(audio_raw):,} -> {len(ac):,} bytes)")

    ext_b     = audio_ext.encode()[:5].ljust(5, b"\x00") 
    integrity = hashlib.sha256(tc + ac).digest()
    
    header = struct.pack(BUNDLE_FMT,
        BUNDLE_MAGIC, session_id, 
        best_tele["id"], a_id,           
        len(tele_raw), len(tc), 
        len(audio_raw), len(ac), 
        ext_b, integrity)

    return header + tc + ac, tele_results

def decompress_bundle(bundle: bytes) -> dict:
    if len(bundle) < BUNDLE_HDR_SZ:
        raise ValueError("Bundle too short")
        
    (magic, session_id, t_id, a_id, t_raw_len, t_comp_len, 
     a_raw_len, a_comp_len, ext_b, stored_hash) = struct.unpack_from(BUNDLE_FMT, bundle)
    
    if magic != BUNDLE_MAGIC:
        raise ValueError("Invalid Bundle Magic")

    # Slice data
    tc = bundle[BUNDLE_HDR_SZ : BUNDLE_HDR_SZ + t_comp_len]
    ac = bundle[BUNDLE_HDR_SZ + t_comp_len : BUNDLE_HDR_SZ + t_comp_len + a_comp_len]

    # Integrity Check
    if hashlib.sha256(tc + ac).digest() != stored_hash:
        raise ValueError("SHA-256 Checksum Mismatch!")

    # Find Tele Decompressor
    t_name, t_dfn = next((n, d[2]) for n, d in TELE_ALGOS.items() if d[0] == t_id)
    # Find Audio Decompressor
    a_name, a_dfn = next((n, d[2]) for n, d in AUDIO_ALGOS.items() if d[0] == a_id)

    return {
        "session_id":     session_id.hex(),
        "tele":           t_dfn(tc),
        "audio":          a_dfn(ac),
        "tele_algo":      t_name,
        "audio_algo":     a_name,
        "audio_ext":      ext_b.rstrip(b"\x00").decode(),
        "tele_raw_len":   t_raw_len,
        "tele_comp_len":  t_comp_len,
        "audio_raw_len":  a_raw_len,
        "audio_comp_len": a_comp_len
    }
