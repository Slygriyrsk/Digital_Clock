import math, os, random, struct, wave
import numpy as np
from scipy.signal import butter, sosfilt, resample
import config as cfg
import pandas as pd

os.makedirs("output", exist_ok=True)

"""
PARAMS = [
    ("Time",                            4, "sin",    0,     45000),
    ("Relative Time Count",             4, "sin",  100,       550),
    ("GPS Time Sync",                   4, "sin",    0,     45000),
    ("Pressure Altitude",               4, "sin",  100,       550),
    ("Indicated Airspeed or Calibrated Airspeed", 8, "osc",  -20,        20),
    ("Heading (Primary flight crew reference)",   8, "osc",  -45,        45),
    ("Normal Acceleration",             4, "sin",    0,       360),
    ("Pitch Attitude",                  8, "osc",  -5,        20),
    ("Roll Attitude",                   4, "noise", -5,         5),
    ("Manual Radio Transmission Keying and CVR/FDR synchronisation reference", 4, "sin",    0,      2500),
    ("Engine Thrust/power - Parameters required to determine Propulsive Thrust/Power on each engine", 4, "ramp",   0,       360),
    ("Cockpit thrust / Power lever position",     1, "ramp",   0,       360),
    ("(see 9a)",                        4, "sin",    0,       550),
    ("Flaps",                           2, "ramp",   0,       360),
    ("Trailing edge flap position",     2, "ramp",  -90,       90),
    ("Cockpit control selection",       2, "sin",    0,     45000),
    ("Slats",                           1, "sin",    0,      0.95),
    ("Leading edge flap (slat) position", 4, "sin",   -5,        20),
    ("Cockpit control selection (slats)", 4, "sin",   -5,        20),
    ("Thrust reverse status",           4, "sin",    0,      2500),
    ("Ground spoiler and speed brake",  4, "osc",   -1,         4),
    ("Ground Spoiler position",         4, "osc",   -5,         5),
    ("Ground Spoiler selection",        8, "noise", -10,       10),
    ("Speed brake position",            8, "noise", -10,       10),
    ("Speed brake selection",           4, "sin",    0,       360),
    ("Total Air Temperature and or Outside Air Temperature", 4, "ramp",   0,       360),
    ("Autopilot/Autothrottle/AFCS mode and engagement status", 2, "ramp",   0,       360),
    ("Longitudinal Acceleration (Body axis)", 2, "ramp",  -90,       90),
    ("Lateral Acceleration",            2, "sin",    0,     45000),
    ("Primary Flight Control surface and Primary Flight Control pilot input", 1, "sin",    0,      0.95),
    ("pitch axis (Primary Flight Control surface / pilot input)", 4, "sin",   -5,        20),
    ("roll axis (Primary Flight Control surface / pilot input)", 4, "sin",   -5,        20),
    ("yaw axis (Primary Flight Control surface / pilot input)", 4, "sin",    0,      2500),
    ("Pitch trim surface position",     4, "sin",    0,       360),
    ("Radio Altitude",                  1, "ramp",   0,       360),
    ("Vertical Beam deviation",         1, "binary",   0,       360),
    ("ILS/GPS/GLS Glide Path",          1, "binary",    0,      360),
    ("MLS Elevation",                   1, "steady",    0,      7),
    ("IRNAV/IAN Vertical Deviation",    1, "binary",     0,      1),
    ("Horizontal Beam deviation",       1, "binary",    0,      1),
    ("ILS/GPS/GLS Localizer",           1, "binary",    0,      1),
    ("MLS Azimuth",                     1, "binary",    0,      1),
    ("IRNAV/IAN Lateral Deviation",     1, "binary",    0,      1),
    ("Marker beacon passage",           1, "binary",    0,      1),
    ("Warnings and cautions",           1, "steady",    0,   8000),
    ("Warnings",                        1, "steady",    0,      9),
    ("Cautions",                        1, "steady",   18,     26),
    ("Each Navigation Receiver Frequency Selection", 1, "steady",  100,    500),
    ("DME 1 and 2 Distances",          1, "steady",   20,     50),
    ("Distance to Runway Threshold (GLS)", 1, "steady",   20,     50),
    ("Distance to Missed Approach Point (IRNAV/IAN)", 1, "steady",   20,     50),
    ("Air - ground status",             2, "noise",     0,       5),
    ("GPWS/TAWS/GCAS status - Selection of terrain display mode including pop-up display status; Terrain alerts, both cautions and warnings, and advisories; On/off switch position", 2, "noise",     0,       5),
    ("Selection of terrain display mode including pop-up display status", 4, "sin",    0,      2500),
    ("Terrain alerts, both cautions and warnings, and advisories", 4, "sin",    0,       360),
    ("On/off switch position",          4, "sin",  100,       550),
    ("Angle of attack",                 4, "osc",  -20,        20),
    ("Low pressure warning / Hydraulic pressure / Pneumatic pressure", 8, "osc",  -45,        45),
    ("Hydraulic pressure",              4, "sin",    0,       360),
    ("Pneumatic pressure",              8, "osc",  -5,        20),
    ("Groundspeed",                     4, "noise", -5,         5),
    ("Landing gear",                    4, "noise", -10,       10),
    ("Landing gear position",           4, "osc",   -1,         4),
    ("Gear selector position",          4, "ramp",   0,       360),
    ("Navigation Data - (Drift Angle; Wind Speed; Wind Direction; Latitude/Longitude)", 4, "ramp",  -90,       90),
    ("Drift Angle",                     2, "ramp",   0,       360),
    ("Wind Speed",                      2, "ramp",  -180,      180),
    ("Wind Direction",                  2, "sin",    0,      2500),
    ("Latitude/Longitude",              4, "sin",    0,       360),
    ("GPS Correction in use",           4, "sin",  100,       550),
    ("Estimated position error",        4, "osc",  -20,        20),
    ("GNSS Altitude",                   4, "osc",  -45,        45),
    ("Brakes",                          8, "noise",    0,       360),
    ("Left and Right Brake Pressure",   8, "noise", -5,         5),
    ("Left and Right Brake Pedal Position", 4, "sin",    0,       360),
    ("Brake temperature",               4, "ramp",   0,       360),
    ("Autobrake level selection",       1, "ramp",   0,       360),
    ("Anti-skid system activation",     1, "sin",    0,     45000),
    ("Additional Engine Parameters",    1, "sin",    0,      0.95),
    ("EPR",                             4, "sin",   -5,        20),
    ("N1",                              4, "sin",   -5,        20),
    ("indicated vibration level",       4, "sin",    0,      2500),
    ("N2",                              4, "sin",  100,       550),
    ("EGT",                             4, "osc",  -20,        20),
    ("fuel flow",                       4, "osc",  -45,        45),
    ("fuel cut-off lever position",     4, "osc",    0,       360),
    ("N3",                              4, "noise", -5,         5),
    ("engine fuel metering valve position", 4, "noise", -10,       10),
    ("Engine oil pressure",             4, "noise", -10,       10),
    ("Blade angle (turboprop)",         4, "osc",   -1,         4),
    ("Condition lever position (turboprop)", 8, "noise", -5,         5),
    ("TCAS/ACAS (Traffic Alert and Collision Avoidance System)", 8, "noise", -10,       10),
    ("Windshear Warning and Caution",   4, "osc",   -1,         4),
    ("Selected Barometric setting",     4, "osc",   -5,         5),
    ("Pilot - Selected Barometric setting", 4, "noise", -10,       10),
    ("First Officer - Selected Barometric setting", 4, "noise", -3,         3),
    ("Selected Altitude (All pilot selectable modes of operation)", 4, "osc", -2000,     2000),
    ("Selected Speed (All pilot selectable modes of operation)", 4, "ramp",   0,       360),
    ("Selected Mach (All pilot selectable modes of operation)", 1, "ramp",   0,       360),
    ("Selected Vertical Speed (All pilot selectable modes of operation)", 1, "sin",    0,      0.95),
    ("Selected Heading (All pilot selectable modes of operation)", 1, "sin",   -5,        20),
    ("Selected Flight Path (All pilot selectable modes of operation)", 1, "steady", -5,        20),
    ("Course/DSTRK (Selected Flight Path)", 1, "steady",    0,      2500),
    ("Path Angle (Selected Flight Path)", 1, "steady",    0,       360),
    ("Final Approach Path (IRNAV/IAN) (Selected Flight Path)", 1, "steady",   0,       360),
    ("Selected Decision Height",        1, "ramp",   0,       360),
    ("EFIS Display Format",             1, "step",   0,       360),
    ("Pilot - EFIS Display Format",     1, "step",   0,      360),
    ("First Officer - EFIS Display Format", 1, "binary",   0,      360),
    ("Multi-function/Engine/Alerts Display format", 1, "binary",    0,      360),
    ("AC Electrical Bus Status",        1, "binary",    0,      7),
    ("DC Electrical Bus status",        1, "binary",    0,      7),
    ("Engine Bleed Valve Position",     1, "binary",    0,      1),
    ("APU Bleed Valve Position",        1, "binary",    0,      1),
    ("Computer Failure",                1, "binary",    0,      1),
    ("Engine Thrust Command",           1, "steady",    0,   8000),
    ("Engine Thrust Target",            1, "steady",    0,      9),
    ("Computed Centre of Gravity",      1, "steady",   18,     26),
    ("Fuel Quantity in each tank system reported to fuel quantity system", 1, "steady",  100,    500),
    ("Head up Display in use",          1, "steady",   20,    50),
    ("Para Visual Display on",          1, "steady",   20,    50),
    ("Operational Stall protection, Stick shaker and pusher activation", 1, "binary",    0,      1),
    ("Primary Navigation System Reference - GNSS, INS, VOR/DME, MLS, Loran C, Localizer Glideslope", 1, "binary",    0,      1),
    ("Ice Detection",                   1, "binary",    0,      1),
    ("Engine warning each engine vibration", 1, "binary",    0,      1),
    ("Engine warning each engine over temperature", 1, "binary",    0,      1),
    ("Engine warning each engine oil pressure low", 1, "binary",    0,      1),
    ("Engine warning each engine over speed", 1, "binary",    0,      1),
    ("Yaw Trim Surface Position",       1, "binary",    0,      1),
    ("Roll Trim Surface Position",      1, "binary",    0,      1),
    ("Yaw or sideslip angle",           1, "binary",    0,      1),
    ("De-icing and/or anti-icing systems selection", 1, "binary",    0,      1),
    ("Hydraulic Pressure (each system)", 1, "binary",    0,      1),
    ("Loss of cabin pressure",          1, "binary",    0,      1),
    ("Cockpit trim control input position - Pitch", 1, "binary",    0,      1),
    ("Cockpit trim control input position - Roll", 1, "binary",    0,      1),
    ("Cockpit trim control input position - Yaw", 1, "binary",    0,      1),
    ("All cockpit flight control input forces", 1, "binary",    0,      1),
    ("Control wheel - cockpit input forces", 1, "binary",    0,      1),
    ("Control column - cockpit input forces", 1, "binary",    0,      1),
    ("Rudder pedal - cockpit input forces", 1, "binary",    0,      1),
    ("Event Marker",                    1, "ramp",       0,   3600),
    ("Date",                            1, "steady",     0,   1024),
    ("ANP or EPE or EPU",               1, "binary",     0,      1),
    ("Cabin pressure altitude",         1, "binary",     0,      1),
    ("Aircraft computed weight",        1, "binary",     0,      1),
    ("Flight director command",         1, "binary",     0,      1),
    ("Left flight director pitch command", 1, "binary",     0,      1),
    ("Left flight director roll command", 1, "binary",     0,      1),
    ("Right flight director pitch command", 1, "binary",     0,      1),
    ("Right flight director roll command", 1, "binary",     0,      1),
    ("Vertical speed",                  1, "binary",     0,      1),
    ("Cabin pressure control and variations", 1, "binary",     0,      1),
    ("Cabin altitude rate",             1, "binary",     0,      1),
    ("Outflow valve position",          1, "binary",     0,      1),
    ("Cabin pressurisation control - selected mode", 1, "binary",     0,      1),
    ("Nose wheel steering",             1, "binary",     0,      1),
    ("Nose wheel steering angle",       1, "binary",     0,      1),
    ("Nose wheel steering control position", 1, "binary",     0,      1),
    ("Aircraft Track",                  1, "binary",     0,      1),
    ("True Airspeed/Mach Number",       1, "binary",     0,      1),
    ("True Airspeed",                   1, "binary",     0,      1),
    ("Mach Number",                     1, "binary",     0,      1),
    ("Takeoff Performance Parameters",  1, "binary",     0,      1),
    ("Vr rotation speed",               1, "binary",     0,      1),
    ("V1",                              1, "binary",     0,      1),
    ("V2",                              1, "binary",     0,      1),
    ("Selected take-off modes or values, used for automatic take-off performance calculations", 1, "binary",     0,      1),
    ("Designation of active procedures", 1, "binary",     0,      1),
    ("Selected SID (standard instrument departure) route", 1, "binary",     0,      1),
    ("Selected STAR (standard terminal arrival) route", 1, "binary",     0,      1),
    ("Next active waypoint",            1, "binary",     0,      1),
    ("Designator of the runway selected for landing", 1, "binary",     0,      1),
    ("Attitude Rates",                  1, "binary",     0,      1),
    ("Pitch Rate",                      1, "binary",     0,      1),
    ("Roll Rate",                       1, "binary",     0,      1),
    ("Yaw Rate",                        1, "binary",     0,      1),
    ("Wheel Speed",                     1, "binary",     0,      1),
    ("Crew-entered information used for performance, control, and engine calculations", 1, "binary",     0,      1),
]
"""

PARAMS = [
    ("Time",                            4, "sin",    0,     45000),
    ("First Officer - Selected Barometric setting", 4, "noise", -3,         3),
    ("Selected Altitude (All pilot selectable modes of operation)", 4, "osc", -2000,     2000),
    ("Selected Decision Height",        1, "ramp",   0,       360),
    ("EFIS Display Format",             1, "step",   0,       360),
]

assert len(PARAMS) >= 5, f"Only {len(PARAMS)} params defined"
#assert len(PARAMS) >= 179, f"Only {len(PARAMS)} params defined"


def _generate(name, rate_hz, waveform, lo, hi, duration_sec):
    rng = random.Random(hash(name) & 0xFFFFFFFF)
    n   = int(rate_hz * duration_sec)
    mid = (hi + lo) / 2
    amp = (hi - lo) / 2
    out = []
    for i in range(n):
        t = i / rate_hz
        if waveform == "sin":
            v = mid + amp * 0.7 * math.sin(2 * math.pi * (1 / max(duration_sec * 0.3, 10)) * t)
        elif waveform == "osc":
            f = 0.1 + rng.random() * 0.2
            v = mid + amp * 0.5 * math.sin(2 * math.pi * f * t) + rng.gauss(0, amp * 0.05)
        elif waveform == "ramp":
            v = lo + (hi - lo) * (t / duration_sec)
        elif waveform == "steady":
            v = mid + rng.uniform(-amp * 0.1, amp * 0.1) + rng.gauss(0, amp * 0.02)
        elif waveform == "noise":
            v = mid + rng.gauss(0, amp * 0.4)
        elif waveform == "step":
            steps = [lo, lo + (hi - lo) * 0.25, lo + (hi - lo) * 0.5, hi]
            v = steps[min(int(t / duration_sec * len(steps)), len(steps) - 1)]
        elif waveform == "binary":
            v = out[-1] if out else lo
            if rng.random() < 0.005:
                v = rng.choice([lo, hi])
        else:
            v = mid
        out.append(max(lo, min(hi, v)))
    return out

def _to_12bit(val, lo, hi):
    return int(round((val - lo) / (hi - lo) * 4095)) & 0xFFF


def _from_12bit(word, lo, hi):
    return lo + (word / 4095.0) * (hi - lo)

#this is for the excel sheet format
# def generate_telemetry():
#     rows=[]
#     for (name, sampling, signal, lo, hi) in PARAMS[:5]:
#         samples=_generate(name, sampling, signal, lo, hi, cfg.DURATION_SEC)
#         words=[_to_12bit(s, lo, hi) for s in samples]
#         rows.append((name, sampling, signal, lo, hi, samples, words))

#     excel_rows=[]
#     for sec in range(cfg.DURATION_SEC):
#         for (name, sampling, signal, lo, hi, samples, words) in rows:
#             for tick in range(int(sampling)):
#                 idx=sec*int(sampling)+tick
#                 if idx<len(words):
#                     excel_rows.append({
#                         "Parameter Name: ": name,
#                         "Sampling time(Hz): ": sampling,
#                         "Signal Type: ": signal,
#                         "low: ": lo,
#                         "High: ": hi
#                     })

#     df=pd.DataFrame(excel_rows)
#     excel_path="output/telemetry_repo.xlsx"
#     df.to_excel(excel_path, index=False)
#     print(f"Telemetry data saved as Excel at {excel_path}")
#     return b"Excel Exported", rows

#this is for the binary folder
def generate_telemetry():
    rows = []
    for (name, rate_hz, wf, lo, hi) in PARAMS[:200]:
        samples = _generate(name, rate_hz, wf, lo, hi, cfg.DURATION_SEC)
        words   = [_to_12bit(s, lo, hi) for s in samples]
        rows.append((name, rate_hz, wf, lo, hi, samples, words))

    buf = bytearray()
    max_rate = max(r[1] for r in rows)
    for sec in range(cfg.DURATION_SEC):
        for (name, rate_hz, wf, lo, hi, samples, words) in rows:
            for tick in range(int(rate_hz)):
                idx = sec * int(rate_hz) + tick
                if idx < len(words):
                    buf += struct.pack(">H", words[idx])

    path = "output/telemetry_raw.bin"
    with open(path, "wb") as f:
        f.write(bytes(buf))
    print(f"Telemetry : {len(PARAMS)} params x {cfg.DURATION_SEC}s -> {len(buf):,}B -> {path}")
    return bytes(buf), rows


# def generate_audio(duration_sec=30):
#     """Synthetic 8kHz 8-bit mono cockpit ambient. Returns raw PCM bytes."""
#     sr  = 8000
#     rng = random.Random(42)
#     out = bytearray()
#     for i in range(sr * duration_sec):
#         t   = i / sr
#         sig = 20 * math.sin(2 * math.pi * 80 * t)
#         sig += rng.gauss(0, 10)
#         if rng.random() < 0.002:
#             sig += 60 * math.sin(2 * math.pi * 300 * t)
#         out.append(max(0, min(255, int(sig + 128))))

#     path = "output/cvr_audio.wav"
#     with wave.open(path, "wb") as wf:
#         wf.setnchannels(1); wf.setsampwidth(1); wf.setframerate(sr)
#         wf.writeframes(bytes(out))
#     print(f"Audio     : {duration_sec}s @ {sr}Hz → {len(out):,}B → {path}")
#     return bytes(out)

def butter_bandpass_filter(data, lowcut, highcut, fs, order=5):
    nyq = 0.5 * fs
    low = lowcut / nyq
    high = highcut / nyq
    high = min(high, 0.99) 
    
    sos = butter(order, [low, high], btype='band', output='sos')
    return sosfilt(sos, data)

def generate_audio(mode="synthetic", file_path=None, duration_sec=30):
    sr=8000

    if mode=="synthetic":
        print("--- Generating Synthetic Cockpit Ambient ---")
        rng = random.Random(42)
        out = bytearray()
        for i in range(sr * duration_sec):
            t = i / sr
            sig = 20 * math.sin(2 * math.pi * 80 * t)
            sig += rng.gauss(0, 10)
            if rng.random() < 0.002:
                sig += 60 * math.sin(2 * math.pi * 300 * t)
            out.append(max(0, min(255, int(sig + 128))))
        audio_bytes = bytes(out)
    elif mode=="pre-recorded":
        if not file_path or not os.path.exists(file_path):
            raise FileNotFoundError(f"Audio file not found at: {file_path}")
        
        with wave.open(file_path, "rb") as wf:
            fs = wf.getframerate()  # This is 44100
            sw = wf.getsampwidth()
            n_frames = wf.getnframes()
            
            raw_data = wf.readframes(n_frames)
            dtype = np.int16 if sw == 2 else np.uint8
            audio_array = np.frombuffer(raw_data, dtype=dtype)

            filtered_audio = butter_bandpass_filter(audio_array, 150, 8000, fs)

            num_samples = int(len(filtered_audio) * (sr / fs))
            resampled_audio = resample(filtered_audio, num_samples)
            
            resampled_audio = np.interp(resampled_audio, (resampled_audio.min(), resampled_audio.max()), (0, 255))
            audio_bytes = resampled_audio.astype(np.uint8).tobytes()

    output_path = "output/current_audio.wav"
    os.makedirs("output", exist_ok=True)
    with wave.open(output_path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(1) # 8-bit
        wf.setframerate(sr)
        wf.writeframes(audio_bytes)
        
    return audio_bytes


if __name__ == "__main__":
    os.makedirs("output", exist_ok=True)
    tele, _ = generate_telemetry()
    audio   = generate_audio()
    print(f"Combined raw: {len(tele) + len(audio):,}B")