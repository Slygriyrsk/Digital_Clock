#!/usr/bin/env python3
"""
aircraft_quic.py  —  Aircraft-side FDR/CVR sender over QUIC (RFC 9000 + TLS 1.3).

Identical to aircraft.py in every respect EXCEPT the transport:
  - UDP raw sockets + HMAC-per-packet  →  QUIC streams + TLS-1.3 AEAD
  - DTN state, FEC, NetworkSim, bundle building, ECDSA signing : ALL UNCHANGED
  - No per-packet HMAC needed — TLS 1.3 encrypts + authenticates every byte

Streams used:
  stream 0  : aircraft → ground  (bundle chunks, length-prefixed)
  stream 4  : ground → aircraft  (bitmap ACKs, length-prefixed)
  stream 8  : ground → aircraft  (JSON meta/diagnostic, length-prefixed)

Run:
  python gen_certs.py          # only once
  python aircraft_quic.py [--audio path/to/audio.flac]
"""

import argparse
import asyncio
import hashlib
import json
import os
import struct
import sys
import time
import uuid
import wave

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import config as cfg
from telemetry     import generate_telemetry, generate_audio
from compress      import compress_bundle, decompress_bundle, BUNDLE_HDR_SZ, BUNDLE_FMT
from crypto        import (ecdsa_keygen, ecdsa_sign, save_ecdsa_keys,
                            load_ecdsa_private, benchmark)
from protocol_quic import (make_packet, parse_ack, FEC_K,
                            FLAG_PARITY, FLAG_RETX,
                            BUNDLE_STREAM_ID, ACK_STREAM_ID, META_STREAM_ID,
                            PKT_HDR_SZ)

from aioquic.asyncio          import connect
from aioquic.asyncio.protocol import QuicConnectionProtocol
from aioquic.quic.configuration import QuicConfiguration
from aioquic.quic.events      import (StreamDataReceived, HandshakeCompleted,
                                       ConnectionTerminated)

os.makedirs("output", exist_ok=True)
os.makedirs("keys",   exist_ok=True)

CERT_PATH = "certs/quic_cert.pem"

# ── QUIC ground stations (mirrors GROUND_STATIONS but with QUIC ports) ────────
QUIC_GROUND_STATIONS = [
    {"host": "127.0.0.1", "port": 9010, "name": "GS-QUIC-Primary"},
    {"host": "127.0.0.1", "port": 9011, "name": "GS-QUIC-Backup"},
    {"host": "127.0.0.1", "port": 9012, "name": "GS-QUIC-Charlie"},
]

# ── NetworkSim (identical to aircraft.py) ─────────────────────────────────────
import random

class NetworkSim:
    def __init__(self):
        self._rng         = random.Random(42)
        self._session_t0  = time.time()
        self._burst_count = 0
        self.stats = {"sent": 0, "dropped": 0, "blackout": 0, "burst_drops": 0}

    def _in_blackout(self):
        elapsed = time.time() - self._session_t0
        return cfg.NET_BLACKOUT_START_S <= elapsed <= cfg.NET_BLACKOUT_END_S

    def should_drop(self, chunk_idx):
        if self._in_blackout():
            self.stats["blackout"] += 1
            rem = cfg.NET_BLACKOUT_END_S - (time.time() - self._session_t0)
            print(f"  [BLACKOUT] chunk {chunk_idx} dropped (ends in {rem:.1f}s)")
            return True
        if self._burst_count > 0:
            self._burst_count -= 1
            self.stats["burst_drops"] += 1
            print(f"  [BURST-DROP] chunk {chunk_idx} ({self._burst_count} more)")
            return True
        if self._rng.random() < cfg.NET_DROP_PROB:
            if self._rng.random() < 0.3:
                self._burst_count = cfg.NET_BURST_SIZE - 1
                print(f"  [BURST-START] chunk {chunk_idx} — burst of {cfg.NET_BURST_SIZE}")
            else:
                print(f"  [RAND-DROP] chunk {chunk_idx}")
            self.stats["dropped"] += 1
            return True
        return False

    def record_sent(self):
        self.stats["sent"] += 1

    def print_summary(self):
        s = self.stats
        total = s["sent"] + s["dropped"] + s["blackout"] + s["burst_drops"]
        lost  = s["dropped"] + s["blackout"] + s["burst_drops"]
        pct   = 100 * lost / max(1, total)
        print(f"\n  Network sim summary (QUIC transport):")
        print(f"    Attempted       : {total}")
        print(f"    Sent            : {s['sent']}")
        print(f"    Random drops    : {s['dropped']}")
        print(f"    Burst drops     : {s['burst_drops']}")
        print(f"    Blackout drops  : {s['blackout']}")
        print(f"    Total loss rate : {pct:.1f}%")
        print(f"    Note: QUIC retransmits at QUIC layer too — app-level FEC is extra")


_net = NetworkSim()


# ── Key helpers (identical to aircraft.py) ────────────────────────────────────

def ensure_keys():
    if not os.path.exists(cfg.PRIVATE_KEY_PATH):
        priv, pub = ecdsa_keygen()
        save_ecdsa_keys(priv, pub)
        print(f"[KEYS] Generated -> {cfg.PRIVATE_KEY_PATH}")
        print(f"       Copy {cfg.PUBLIC_KEY_PATH} to ground station keys/")
    return load_ecdsa_private()


def load_audio_file(path):
    if not os.path.exists(path):
        raise FileNotFoundError(f"Audio file not found: {path}")
    ext = os.path.splitext(path)[1].lower()
    if ext == ".flac":
        print(f"Audio in : {path} (FLAC passthrough)")
        with open(path, "rb") as f:
            return f.read(), ext
    with wave.open(path, "rb") as wf:
        src_rate  = wf.getframerate()
        channels  = wf.getnchannels()
        sampwidth = wf.getsampwidth()
        n_frames  = wf.getnframes()
        raw       = wf.readframes(n_frames)
    print(f"  Audio in  : {path} {src_rate}Hz {channels}ch {sampwidth*8}bit")
    if sampwidth == 2:
        samples = [s / 32767.0 for s in struct.unpack(f"<{len(raw)//2}h", raw)]
    elif sampwidth == 1:
        samples = [(b - 128) / 128.0 for b in raw]
    else:
        samples = [s / 2147483647.0 for s in struct.unpack(f"<{len(raw)//4}i", raw)]
    if channels == 2:
        samples = samples[::2]
    TARGET = 8000
    if src_rate != TARGET:
        ratio = TARGET / src_rate
        new_n = int(len(samples) * ratio)
        resampled = []
        for i in range(new_n):
            src = i / ratio; lo = int(src); hi = min(lo+1, len(samples)-1)
            resampled.append(samples[lo]*(1-(src-lo)) + samples[hi]*(src-lo))
        samples = resampled
    pcm = struct.pack(f"<{len(samples)}h",
                      *[max(-32768, min(32767, int(s*32767))) for s in samples])
    print(f"  Audio norm: {TARGET}Hz mono 16-bit {len(samples)} samples {len(pcm):,}B")
    return pcm, ext


def load_dtn_state():
    if os.path.exists(cfg.DTN_STATE_FILE):
        with open(cfg.DTN_STATE_FILE) as f:
            raw = json.load(f)
        raw["acked_chunks"] = set(raw.get("acked_chunks", []))
        raw["retry_count"]  = {int(k): v for k, v in raw.get("retry_count", {}).items()}
        raw["next_retry"]   = {int(k): v for k, v in raw.get("next_retry", {}).items()}
        return raw
    return {}


def save_dtn_state(state):
    out = {
        "session_id":   state["session_id"],
        "bundle_hash":  state["bundle_hash"],
        "total_chunks": state["total_chunks"],
        "acked_chunks": sorted(state["acked_chunks"]),
        "retry_count":  {str(k): v for k, v in state["retry_count"].items()},
        "next_retry":   {str(k): v for k, v in state["next_retry"].items()},
    }
    with open(cfg.DTN_STATE_FILE, "w") as f:
        json.dump(out, f)


def build_signed_bundle(session_id, private_key, audio_path=None):
    tele_raw, _ = generate_telemetry()
    resolved_path = audio_path or getattr(cfg, "CVR_AUDIO_PATH", None)
    if resolved_path and os.path.exists(str(resolved_path)):
        audio_raw, audio_ext = load_audio_file(resolved_path)
    else:
        print("  Audio : no path given — generating synthetic CVR audio")
        audio_raw = generate_audio(mode="synthetic")
        audio_ext = ".wav"

    bundle, _ = compress_bundle(session_id, tele_raw, audio_raw, audio_ext)
    payload_to_sign = bundle[BUNDLE_HDR_SZ:]

    print("\nCrypto comparison (ECDSA P-256 vs Lattice-LWE)")
    bm = benchmark(payload_to_sign, n=3)
    print(f"  ECDSA P-256  sign: {bm['ecdsa_sign_ms']:.1f}ms  "
          f"verify: {bm['ecdsa_verify_ms']:.1f}ms  sig: {bm['ecdsa_sig_bytes']}B")
    print("=" * 50)

    ecdsa_sig   = ecdsa_sign(private_key, payload_to_sign)
    signed      = bundle + struct.pack("!H", len(ecdsa_sig)) + ecdsa_sig
    bundle_hash = hashlib.sha256(signed).hexdigest()
    print(f"\nSigned bundle: {len(signed):,}B  hash: {bundle_hash[:16]}...")
    return signed, bundle_hash


def _xor_parity(payloads):
    max_len = max(len(p) for p in payloads)
    result  = bytearray(max_len)
    for p in payloads:
        for i, b in enumerate(p):
            result[i] ^= b
    return bytes(result)


# ── QUIC client protocol ───────────────────────────────────────────────────────

class FDRAircraftQuic(QuicConnectionProtocol):
    """
    Manages one QUIC connection to a ground station.
    Exposes:
      .send_chunks_done  — asyncio.Event set when all chunks ACKed
      .acked             — set of acked chunk indices
    """

    def __init__(self, *args, session_id=b"", total=0, **kwargs):
        super().__init__(*args, **kwargs)
        self._session_id  = session_id
        self._total       = total
        self._ack_buf     = bytearray()
        self._meta_buf    = bytearray()
        self.acked        = set()
        self.send_chunks_done = asyncio.Event()
        self._handshake_ok    = asyncio.Event()
        self._quic_meta       = {}

    def quic_event_received(self, event):
        if isinstance(event, HandshakeCompleted):
            self._quic_meta = {
                "quic_version": hex(self._quic._version),
                "tls_cipher":   getattr(self._quic.tls, "_cipher_suite", None)
                                or "TLS_AES_128_GCM_SHA256",
            }
            print(f"\n  [QUIC-CLIENT] Handshake complete with ground station")
            print(f"  [QUIC-CLIENT] Version : {self._quic_meta['quic_version']}")
            print(f"  [QUIC-CLIENT] Cipher  : {self._quic_meta['tls_cipher']}")
            print(f"  [QUIC-CLIENT] All transmission is TLS 1.3 encrypted from here")
            print(f"QUIC_HANDSHAKE:TLS1.3|{self._quic_meta['quic_version']}|{self._quic_meta['tls_cipher']}")
            self._handshake_ok.set()

        elif isinstance(event, StreamDataReceived):
            if event.stream_id == ACK_STREAM_ID:
                self._handle_acks(event.data)
            elif event.stream_id == META_STREAM_ID:
                self._handle_meta(event.data)

        elif isinstance(event, ConnectionTerminated):
            print(f"  [QUIC-CLIENT] Connection terminated: {event.error_code}")
            self.send_chunks_done.set()

    def _handle_acks(self, data: bytes):
        self._ack_buf.extend(data)
        while len(self._ack_buf) >= 4:
            msg_len = struct.unpack_from("!I", self._ack_buf, 0)[0]
            if len(self._ack_buf) < 4 + msg_len:
                break
            msg = bytes(self._ack_buf[4: 4 + msg_len])
            del self._ack_buf[: 4 + msg_len]
            try:
                win_start, bitmap = parse_ack(msg)
                for bit in range(64):
                    if bitmap & (1 << bit):
                        self.acked.add(win_start + bit)
            except ValueError:
                pass

    def _handle_meta(self, data: bytes):
        self._meta_buf.extend(data)
        while len(self._meta_buf) >= 4:
            msg_len = struct.unpack_from("!I", self._meta_buf, 0)[0]
            if len(self._meta_buf) < 4 + msg_len:
                break
            msg = bytes(self._meta_buf[4: 4 + msg_len])
            del self._meta_buf[: 4 + msg_len]
            try:
                ev = json.loads(msg.decode())
                print(f"  [META from GS] {ev}")
            except Exception:
                pass

    async def wait_handshake(self):
        await asyncio.wait_for(self._handshake_ok.wait(), timeout=10.0)

    def send_framed(self, stream_id: int, payload: bytes):
        """Send length-prefixed message on a QUIC stream."""
        frame = struct.pack("!I", len(payload)) + payload
        self._quic.send_stream_data(stream_id, frame)
        self.transmit()


# ── Bundle sender (async) ─────────────────────────────────────────────────────

async def send_bundle_quic(bundle: bytes, session_id: bytes, state: dict, audio_path=None):
    raw_chunks = [bundle[i:i+cfg.CHUNK_SIZE] for i in range(0, len(bundle), cfg.CHUNK_SIZE)]
    total      = len(raw_chunks)
    state["total_chunks"] = total

    fec_parities = {}
    for grp_start in range(0, total, FEC_K):
        grp_end = min(grp_start + FEC_K, total)
        grp_id  = grp_start // FEC_K
        fec_parities[grp_id] = _xor_parity(raw_chunks[grp_start:grp_end])

    print(f"\n{'='*60}")
    print(f"  QUIC Bundle Sender")
    print(f"  Session     : {session_id.hex()[:16]}...")
    print(f"  Chunks      : {total}  ({cfg.CHUNK_SIZE}B each)")
    print(f"  FEC groups  : {len(fec_parities)}  (1 parity per {FEC_K} data chunks)")
    print(f"  Stations    : {[gs['name'] for gs in QUIC_GROUND_STATIONS]}")
    print(f"  Transport   : QUIC RFC9000 + TLS 1.3  (no per-pkt HMAC needed)")
    print(f"{'='*60}\n")

    # Connect to all ground stations concurrently
    quic_cfg = QuicConfiguration(is_client=True)
    quic_cfg.verify_mode = False      # self-signed cert; production: load CA bundle
    quic_cfg.load_verify_locations(CERT_PATH)

    connections: list[FDRAircraftQuic] = []
    for gs in QUIC_GROUND_STATIONS:
        try:
            _, proto = await connect(
                gs["host"], gs["port"],
                configuration=quic_cfg,
                create_protocol=lambda *a, **kw: FDRAircraftQuic(
                    *a, session_id=session_id, total=total, **kw
                ),
                wait_connected=False,
            )
            await proto.wait_handshake()
            connections.append(proto)
            print(f"  [QUIC] Connected to {gs['name']} ({gs['host']}:{gs['port']})")
        except Exception as e:
            print(f"  [QUIC] Could not connect to {gs['name']}: {e} — skipping")

    if not connections:
        print("  [QUIC] ERROR: No ground stations reachable. Aborting.")
        return

    acked       = state["acked_chunks"]
    retry_count = state["retry_count"]
    next_retry  = state["next_retry"]
    seq         = state.get("last_seq", 0)

    def elapsed_fmt():
        return f"{time.time() - _net._session_t0:.1f}s"

    def _send_chunk_to_all(idx, payload, flags=0, fec_grp=0):
        nonlocal seq
        seq += 1
        if not (flags & FLAG_PARITY) and _net.should_drop(idx):
            return seq
        pkt = make_packet(session_id, seq, idx, total, payload, flags, fec_grp)
        for conn in connections:
            try:
                conn.send_framed(BUNDLE_STREAM_ID, pkt)
            except Exception as e:
                print(f"  [QUIC-SEND-ERR] {e}")
        _net.record_sent()
        return seq

    # Merge acked sets from all connections
    def _refresh_acked():
        for conn in connections:
            acked.update(conn.acked)

    try:
        while len(acked) < total:
            _refresh_acked()

            for idx in range(total):
                if idx in acked:
                    continue
                now = time.time()
                if now < next_retry.get(idx, 0):
                    continue
                rc = retry_count.get(idx, 0)
                if rc > cfg.DTN_MAX_RETRIES:
                    print(f"  [GIVE-UP] chunk {idx} after {rc} retries")
                    acked.add(idx)
                    continue

                grp_id = idx // FEC_K
                flags  = FLAG_RETX if rc > 0 else 0
                last_seq = _send_chunk_to_all(idx, raw_chunks[idx], flags, grp_id)

                if (idx + 1) % FEC_K == 0 or idx == total - 1:
                    _send_chunk_to_all(grp_id * FEC_K, fec_parities[grp_id],
                                       FLAG_PARITY, grp_id)

                retry_count[idx] = rc + 1
                backoff = min(cfg.DTN_BASE_SEC * (2 ** rc), cfg.DTN_MAX_SEC)
                next_retry[idx] = time.time() + backoff

                await asyncio.sleep(0.001)
                _refresh_acked()

                tag = "RETX" if rc > 0 else "SENT"
                print(f"  [{tag}] t={elapsed_fmt()}  chunk {idx+1:>4}/{total}  "
                      f"seq={last_seq:<5}  retry={rc}  "
                      f"acked={len(acked)}/{total}  [QUIC/TLS1.3]")

            print(f"PROGRESS:{len(acked)}:{total}", flush=True)
            state["last_seq"] = seq
            save_dtn_state(state)

            if len(acked) < total:
                missing = [i for i in range(total) if i not in acked]
                earliest = min(next_retry.get(i, 0) for i in missing)
                wait = max(0, earliest - time.time())
                if wait > 0:
                    print(f"  [DTN] waiting {wait:.1f}s before next retry…")
                    await asyncio.sleep(min(wait, 2.0))

    except asyncio.CancelledError:
        print("\nCancelled — DTN state saved.")
    finally:
        _net.print_summary()
        for conn in connections:
            conn.close()


# ── Entry point ───────────────────────────────────────────────────────────────

async def _async_main(args):
    private_key = ensure_keys()
    session_id  = uuid.uuid4().bytes

    state = load_dtn_state()
    if state:
        print(f"Resuming DTN session {state['session_id'][:16]}  "
              f"({len(state['acked_chunks'])} chunks already ACKed)")
        session_id  = bytes.fromhex(state["session_id"])
        bundle_path = "output/bundle_signed_quic.bin"
        if os.path.exists(bundle_path):
            with open(bundle_path, "rb") as f:
                bundle = f.read()
        else:
            bundle, bh = build_signed_bundle(session_id, private_key, args.audio)
            with open(bundle_path, "wb") as f:
                f.write(bundle)
    else:
        bundle, bundle_hash = build_signed_bundle(session_id, private_key, args.audio)
        bundle_path = "output/bundle_signed_quic.bin"
        with open(bundle_path, "wb") as f:
            f.write(bundle)
        state = {
            "session_id":   session_id.hex(),
            "bundle_hash":  bundle_hash,
            "total_chunks": 0,
            "acked_chunks": set(),
            "retry_count":  {},
            "next_retry":   {},
        }
        save_dtn_state(state)
        print(f"New QUIC session: {session_id.hex()[:16]}...")

    await send_bundle_quic(bundle, session_id, state, args.audio)

    print(f"\nSession complete. Chunks ACKed: "
          f"{len(state['acked_chunks'])}/{state['total_chunks']}")
    if len(state["acked_chunks"]) >= state["total_chunks"]:
        if os.path.exists(cfg.DTN_STATE_FILE):
            os.remove(cfg.DTN_STATE_FILE)
        print("DTN state cleared (all chunks ACKed).")
        print("Session complete — all chunks ACKed.")


def main():
    ap = argparse.ArgumentParser(description="Aircraft sender — QUIC transport")
    ap.add_argument("--audio", default=None,
                    help="Path to .wav or .flac audio file. "
                         "Falls back to config.CVR_AUDIO_PATH, then synthetic.")
    args = ap.parse_args()

    if not os.path.exists(CERT_PATH):
        print(f"ERROR: TLS cert not found at {CERT_PATH}. Run:  python gen_certs.py")
        sys.exit(1)

    try:
        asyncio.run(_async_main(args))
    except KeyboardInterrupt:
        print("\nAircraft sender stopped.")


if __name__ == "__main__":
    main()
