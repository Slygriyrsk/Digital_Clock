"""
gui_quic.py  —  Aircraft-side GUI  (QUIC variant)

IDENTICAL to gui.py in every widget, layout, credential, and behaviour.
Two additions only:
  1. Launches aircraft_quic.py instead of aircraft.py
  2. Small "QUIC Transport" panel in the bottom-left showing live handshake
     cipher, version, and encryption status — updates from stdout parsing.
"""

import os
import queue
import sys
import subprocess
import threading
import tkinter as tk
from tkinter import messagebox, ttk

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

import telemetry as tele
import config    as cfg

try:
    import sounddevice as sd
    import soundfile   as sf
    _AUDIO_OK = True
except ImportError:
    _AUDIO_OK = False

audio_queue      = queue.Queue()
recording_stream = None


# ── Audio helpers (identical to gui.py) ──────────────────────────────────────

def callback(indata, frames, time_info, status):
    audio_queue.put(indata.copy())


def start_recording():
    global recording_stream
    if not _AUDIO_OK:
        messagebox.showwarning("No audio", "sounddevice / soundfile not installed.")
        return
    while not audio_queue.empty():
        audio_queue.get()
    recording_stream = sd.InputStream(samplerate=48000, channels=1, callback=callback)
    recording_stream.start()
    btn_start_rec.config(state=tk.DISABLED, bg="lightgray")
    btn_stop_rec.config(state=tk.NORMAL, bg="red", fg="white")


def stop_recording():
    global recording_stream
    if not _AUDIO_OK or recording_stream is None:
        return
    recording_stream.stop(); recording_stream.close(); recording_stream = None
    audio_data = []
    while not audio_queue.empty():
        audio_data.append(audio_queue.get())
    if audio_data:
        import numpy as np
        sf.write("cockpit_audio.flac", np.concatenate(audio_data, axis=0), 48000)
    btn_start_rec.config(state=tk.NORMAL,
                         bg="SystemButtonFace" if os.name == "nt" else "white")
    btn_stop_rec.config(state=tk.DISABLED, bg="lightgray", fg="black")


def Play_audio():
    if not _AUDIO_OK:
        return
    if os.path.exists("cockpit_audio.flac"):
        mb = os.path.getsize("cockpit_audio.flac") / 1048576
        print(f"Audio File Size: {mb:.2f} MB")
        data, fs = sf.read("cockpit_audio.flac")
        sd.play(data, fs); sd.wait()
    else:
        messagebox.showwarning("No File", "No recording found.")


def Stop_Audio():
    if _AUDIO_OK:
        sd.stop()
    messagebox.showinfo("Stopped", "Audio playback stopped.")


# ── Telemetry / plot (identical to gui.py) ───────────────────────────────────

def simulation():
    try:
        rows = generation()
        messagebox.showinfo("Success",
                            f"Telemetry generated for {cfg.DURATION_SEC} seconds.")
        plot_data(rows)
    except Exception as e:
        messagebox.showerror("Error", f"Simulation failed: {e}")


def generation():
    rows = []
    for p in tele.PARAMS:
        name, rate_hz, wf, lo = p[0], p[1], p[2], p[3]
        hi = p[4] if len(p) > 4 else 100
        samples = tele._generate(name, rate_hz, wf, lo, hi, cfg.DURATION_SEC)
        rows.append((name, rate_hz, wf, lo, hi, samples, []))
    return rows


def plot_data(rows):
    fig.clear()
    plottable = rows[:5]
    n = len(plottable)
    if n == 0:
        canvas.draw(); return
    subplots = fig.subplots(n, 1, sharex=True)
    fig.tight_layout(pad=1.5)
    for i, row in enumerate(plottable):
        name, _, _, lo, hi, samples, _ = row
        ax = subplots[i] if n > 1 else subplots
        ax.plot(samples, color=f"C{i}", linewidth=1.2)
        ax.set_title(f"Plot: {name}", fontsize=9, loc="left", pad=4)
        ax.set_ylabel(name[:12] + "…", fontsize=8, rotation=0, labelpad=35, ha="right")
        ax.set_ylim(lo - abs(lo)*0.1 if lo != 0 else -1,
                    hi + abs(hi)*0.1 if hi != 0 else 1)
        ax.grid(True, linestyle="--", alpha=0.5)
    canvas.draw()


# ── QUIC stdout monitor ───────────────────────────────────────────────────────

def monitor_aircraft_stream(process):
    """Reads aircraft_quic.py stdout and updates status + QUIC panel."""
    root.after(0, lambda: status_canvas.itemconfig(status_light, fill="orange"))
    root.after(0, lambda: status_txt.config(text="Transmitting via QUIC…", fg="orange"))
    try:
        while True:
            line = process.stdout.readline()
            if not line:
                break
            s = line.decode("utf-8", errors="replace").strip()
            print(s)

            # ── QUIC handshake line ──
            # Format:  QUIC_HANDSHAKE:TLS1.3|0x1|TLS_AES_128_GCM_SHA256
            if s.startswith("QUIC_HANDSHAKE:"):
                parts = s[len("QUIC_HANDSHAKE:"):].split("|")
                tls_v  = parts[0] if len(parts) > 0 else "TLS1.3"
                qver   = parts[1] if len(parts) > 1 else "—"
                cipher = parts[2] if len(parts) > 2 else "—"
                root.after(0, lambda v=tls_v:  _q["tls"].config(text=v,    fg="#00aa00"))
                root.after(0, lambda v=qver:   _q["ver"].config(text=v,    fg="#00aa00"))
                root.after(0, lambda v=cipher: _q["cip"].config(text=v,    fg="#00aa00"))
                root.after(0, lambda:          _q["enc"].config(
                    text="✔ ENCRYPTED", fg="#00aa00"))
                root.after(0, lambda:          _q["hmac"].config(
                    text="Not needed — TLS 1.3 AEAD", fg="gray"))

            # ── session complete ──
            if ("session complete" in s.lower() or
                    "all chunks acked" in s.lower()):
                root.after(0, lambda: status_canvas.itemconfig(status_light, fill="green"))
                root.after(0, lambda: status_txt.config(
                    text="All Data Sent via QUIC! [OK]", fg="green"))

    except Exception as e:
        print(f"Monitor error: {e}")
    finally:
        root.after(0, lambda: status_canvas.itemconfig(status_light, fill="red"))
        root.after(0, lambda: status_txt.config(text="Transmission Off", fg="red"))


# ── Admin / launch ────────────────────────────────────────────────────────────

def aircraft_side_quic():
    """Launch aircraft_quic.py — drop-in replacement for aircraft.py."""
    return subprocess.Popen(
        [sys.executable, "aircraft_quic.py"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )


def warning_pop():
    messagebox.showwarning("Not Authorized!", "Please give correct credentials")


def admin_helper():
    username = entry1.get().strip()
    password = entry2.get().strip()
    if username == "Sushil" and password == "0987":
        simulation()
        proc = aircraft_side_quic()
        threading.Thread(target=monitor_aircraft_stream,
                         args=(proc,), daemon=True).start()
    else:
        warning_pop()


# ── GUI build ─────────────────────────────────────────────────────────────────

root = tk.Tk()
root.title("Sender  [QUIC]")
root.geometry("1100x640")

control_frame = tk.Frame(root, padx=15, pady=15)
control_frame.pack(side=tk.LEFT, fill=tk.Y)

tk.Label(control_frame, text="Airplane Onboard System  [QUIC]",
         font=("Arial", 10, "bold")).grid(row=0, column=0, columnspan=2, pady=10)

tk.Label(control_frame, text="Admin ").grid(row=1, column=0, padx=10, pady=5)
entry1 = tk.Entry(control_frame)
entry1.grid(row=1, column=1, padx=10, pady=5)

tk.Label(control_frame, text="Password ").grid(row=2, column=0, padx=10, pady=5)
entry2 = tk.Entry(control_frame, show="*")
entry2.grid(row=2, column=1, padx=10, pady=5)

tk.Button(control_frame, text="Start Transmission", width=25,
          command=admin_helper).grid(row=3, column=0, padx=5, pady=10)
tk.Button(control_frame, text="Stop Transmission", width=25,
          command=root.destroy).grid(row=3, column=1, padx=5, pady=10)

btn_start_rec = tk.Button(control_frame, text="🎙️ Turn On Mic",
                           width=25, command=start_recording)
btn_start_rec.grid(row=4, column=0, padx=5, pady=5)

btn_stop_rec = tk.Button(control_frame, text="🛑 Stop Recording",
                          width=25, command=stop_recording, state=tk.DISABLED)
btn_stop_rec.grid(row=4, column=1, padx=5, pady=5)

tk.Button(control_frame, text="▶️ Play Recording",
          width=25, command=Play_audio).grid(row=5, column=0, padx=5, pady=5)
tk.Button(control_frame, text="⏹ Stop Audio",
          width=25, command=Stop_Audio).grid(row=5, column=1, padx=5, pady=5)

status_canvas = tk.Canvas(control_frame, width=30, height=30, highlightthickness=0)
status_canvas.grid(row=6, column=0, padx=10, pady=10, sticky=tk.E)
status_light = status_canvas.create_oval(5, 5, 25, 25, fill="gray")

status_txt = tk.Label(control_frame, text="System Idle",
                       font=("Arial", 10, "bold"), fg="gray")
status_txt.grid(row=6, column=1, padx=5, pady=10, sticky=tk.W)

# ── QUIC panel (the only addition vs gui.py) ──────────────────────────────────
quic_frame = tk.LabelFrame(control_frame, text="⚡ QUIC Transport",
                            font=("Arial", 9, "bold"),
                            bg="#f0f8ff", padx=10, pady=6)
quic_frame.grid(row=7, column=0, columnspan=2, sticky="ew",
                padx=5, pady=(8, 2))

def _qrow(label, key, row):
    tk.Label(quic_frame, text=label, font=("Arial", 8), bg="#f0f8ff",
             anchor="w").grid(row=row, column=0, sticky="w")
    v = tk.Label(quic_frame, text="—", font=("Arial", 8, "bold"),
                 fg="#888", bg="#f0f8ff", anchor="w")
    v.grid(row=row, column=1, sticky="w", padx=(6, 0))
    quic_frame.grid_columnconfigure(1, weight=1)
    return v

_q = {}
_q["tls"]  = _qrow("TLS version:",    "tls",  0)
_q["ver"]  = _qrow("QUIC version:",   "ver",  1)
_q["cip"]  = _qrow("Cipher:",         "cip",  2)
_q["enc"]  = _qrow("In-flight data:", "enc",  3)
_q["hmac"] = _qrow("Per-pkt HMAC:",   "hmac", 4)

# ── Plot area (identical to gui.py) ──────────────────────────────────────────

visual_frame = tk.Frame(root, bg="white", padx=10, pady=10)
visual_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

fig    = Figure(figsize=(7, 4), dpi=100)
canvas = FigureCanvasTkAgg(fig, master=visual_frame)
canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

root.mainloop()
