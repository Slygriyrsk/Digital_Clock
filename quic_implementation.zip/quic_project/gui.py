import tkinter as tk
import subprocess
import sys
from tkinter import messagebox, ttk
import telemetry as tele
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import config as cfg
import os
import sounddevice as sd
import soundfile as sf
import queue
import threading

audio_queue = queue.Queue()
recording_stream = None

def monitor_aircraft_stream(process):
    try:
        root.after(0, lambda: status_canvas.itemconfig(status_light, fill="orange"))
        root.after(0, lambda: status_txt.config(text="Transmitting Data...", fg="orange"))
        
        while True:
            line = process.stdout.readline()
            if not line:
                break
            line_str = line.decode('utf-8', errors='replace').strip()
            print(line_str)
            
            if "Session complete" in line_str or "all chunks ACKed" in line_str.lower():
                root.after(0, lambda: status_canvas.itemconfig(status_light, fill="green"))
                root.after(0, lambda: status_txt.config(text="All Data Sent! [OK]", fg="green"))
                
    except Exception as e:
        print(f"Stream parsing error: {e}")
    finally:
        root.after(0, lambda: status_canvas.itemconfig(status_light, fill="red"))
        root.after(0, lambda: status_txt.config(text="Transmission Off", fg="red"))


def callback(indata, frames, time, status):
    audio_queue.put(indata.copy())

def start_recording():
    global recording_stream
    fs = 48000
    while not audio_queue.empty():
        audio_queue.get()
    
    recording_stream = sd.InputStream(samplerate=fs, channels=1, callback=callback)
    recording_stream.start()
    btn_start_rec.config(state=tk.DISABLED, bg="lightgray")
    btn_stop_rec.config(state=tk.NORMAL, bg="red", fg="white")

def stop_recording():
    global recording_stream
    if recording_stream:
        recording_stream.stop()
        recording_stream.close()
        recording_stream = None
        
        audio_data = []
        while not audio_queue.empty():
            audio_data.append(audio_queue.get())
            
        if audio_data:
            import numpy as np
            full_recording = np.concatenate(audio_data, axis=0)
            sf.write('cockpit_audio.flac', full_recording, 48000)
            
        btn_start_rec.config(state=tk.NORMAL, bg="SystemButtonFace" if os.name == 'nt' else "white")
        btn_stop_rec.config(state=tk.DISABLED, bg="lightgray", fg="black")

def Play_audio():
    if os.path.exists('cockpit_audio.flac'):
        file_bytes = os.path.getsize('cockpit_audio.flac')
        file_mb = file_bytes / (1024 * 1024)
        print(f"Audio File Size: {file_mb:.2f} MB")
        
        data, fs = sf.read('cockpit_audio.flac')
        sd.play(data, fs)
        sd.wait()
    else:
        messagebox.showwarning("No File", "No recording found to play.")

def Stop_Audio():
    sd.stop()
    messagebox.showinfo("Audio playback stopped.")

def simulation():
    try:
        rows = generation()
        messagebox.showinfo("Success", f"Telemetry generated for {cfg.DURATION_SEC} seconds.")

        #refresh_gui()
        plot_data(rows)

    except Exception as e:
        messagebox.showerror("Error", f"Simulation failed: {e}")

def generation():
    rows=[]
    for i in range(len(tele.PARAMS)):
        name = tele.PARAMS[i][0]
        rate_hz = tele.PARAMS[i][1]
        wf = tele.PARAMS[i][2]
        lo = tele.PARAMS[i][3]
        hi = tele.PARAMS[i][4] if len(tele.PARAMS[i]) > 4 else 100 
        
        samples = tele._generate(name, rate_hz, wf, lo, hi, cfg.DURATION_SEC)
        
        rows.append((name, rate_hz, wf, lo, hi, samples, []))
    return rows

# def refresh_gui():
#     file_listbox.delete(0,tk.END)
#     output_dir="output"

#     if os.path.exists(output_dir) and os.listdir(output_dir):
#         for file in os.listdir(output_dir):
#             file_listbox.insert(tk.END, f"{output_dir}/{file}")
#     else:
#         file_listbox.insert(tk.END, "No files found, Run Sim")

def plot_data(rows):
    fig.clear()
    
    plottable_rows = rows[:5] 
    num_plots = len(plottable_rows)
    
    if num_plots == 0:
        canvas.draw()
        return

    subplots = fig.subplots(num_plots, 1, sharex=True)
    fig.tight_layout(pad=1.5)
    
    for i, row in enumerate(plottable_rows):
        name, _, _, lo, hi, samples, _ = row
        
        ax = subplots[i] if num_plots > 1 else subplots
        ax.plot(samples, color=f"C{i}", linewidth=1.2)
        ax.set_title(f"Plot: {name}", fontsize=9, loc='left', pad=4)
        ax.set_ylabel(name[:12] + "...", fontsize=8, rotation=0, labelpad=35, ha='right')
        ax.set_ylim(lo - abs(lo)*0.1 if lo != 0 else -1, hi + abs(hi)*0.1 if hi != 0 else 1)
        ax.grid(True, linestyle="--", alpha=0.5)

    canvas.draw()

def aircraft_side():
    python_executable=sys.executable
    return subprocess.Popen([python_executable, "aircraft.py"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

def warning_pop():
    messagebox.showwarning("Not Authorized!", "Please give correct credentials")

def admin_helper():
    username=entry1.get().strip()
    password=entry2.get().strip()

    if username == "Sushil" and password == "0987":
        simulation()
        proc = aircraft_side()
        threading.Thread(target=monitor_aircraft_stream, args=(proc,), daemon=True).start()
    else:
        warning_pop()

root=tk.Tk()
root.title("Sender")
root.geometry("1100x600")

control_frame = tk.Frame(root, padx=15, pady=15)
control_frame.pack(side=tk.LEFT, fill=tk.Y)

label=tk.Label(control_frame, text="Airplane Onboard System")
label.grid(row=0, column=0, columnspan=2,pady=10)

my_user=tk.Label(control_frame, text="Admin ")
my_user.grid(row=1,column=0,padx=10,pady=5)
entry1=tk.Entry(control_frame)
entry1.grid(row=1,column=1,padx=10,pady=5)

password=tk.Label(control_frame, text="Password ")
password.grid(row=2,column=0,padx=10,pady=5)
entry2=tk.Entry(control_frame, show="*") 
entry2.grid(row=2,column=1,padx=10,pady=5)

button1=tk.Button(control_frame, text="Start Transmisson", width=25, command=admin_helper)
button1.grid(row=3,column=0,padx=5,pady=10)
button2=tk.Button(control_frame, text="Stop Transmisson", width=25, command=root.destroy)
button2.grid(row=3,column=1,padx=5,pady=10)

btn_start_rec = tk.Button(control_frame, text="🎙️ Turn On Mic", width=25, command=start_recording)
btn_start_rec.grid(row=4, column=0, padx=5, pady=5)

btn_stop_rec = tk.Button(control_frame, text="🛑 Stop Recording", width=25, command=stop_recording, state=tk.DISABLED)
btn_stop_rec.grid(row=4, column=1, padx=5, pady=5)

button3 = tk.Button(control_frame, text="▶️ Play Recording", width=25, command=Play_audio)
button3.grid(row=5, column=0, padx=5, pady=5)

button4=tk.Button(control_frame,text="▶️ Stop Recording", width=25, command=Stop_Audio)
button4.grid(row=5, column=1, padx=5, pady=5)

status_canvas = tk.Canvas(control_frame, width=30, height=30, highlightthickness=0)
status_canvas.grid(row=6, column=0, padx=10, pady=10, sticky=tk.E)
status_light = status_canvas.create_oval(5, 5, 25, 25, fill="gray") # Starts Idle (Gray)

status_txt = tk.Label(control_frame, text="System Idle", font=("Arial", 10, "bold"), fg="gray")
status_txt.grid(row=6, column=1, padx=5, pady=10, sticky=tk.W)

# file_listbox = tk.Listbox(control_frame, width=32, height=10)
# file_listbox.grid(row=5, column=0, columnspan=2, pady=10)

visual_frame = tk.Frame(root, bg="white", padx=10, pady=10)
visual_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

fig = Figure(figsize=(7, 4), dpi=100)
canvas = FigureCanvasTkAgg(fig, master=visual_frame)
canvas_widget = canvas.get_tk_widget()
canvas_widget.pack(fill=tk.BOTH, expand=True)

#refresh_gui()
root.mainloop()