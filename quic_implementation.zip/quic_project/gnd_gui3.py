import tkinter as tk
import subprocess
import sys
import config as cfg
from tkinter import messagebox, ttk
import os
import struct
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import compress as comp
import telemetry as tele
import glob
import sounddevice as sd
import soundfile as sf
import threading
from tkinter import scrolledtext

active_session=None
metric_labels={}

#audio bundle is not decompressed for adpacm but for pcm
def play_received_audio():
    audio_pattern = "output/received/audio_*.flac"
    found_audio = glob.glob(audio_pattern)
    
    if not found_audio:
        messagebox.showwarning("No File", "No received audio recordings found to play.")
        return
        
    latest_audio_path = found_audio[-1]
    
    try:
        file_bytes = os.path.getsize(latest_audio_path)
        file_mb = file_bytes / (1024 * 1024)
        print(f"Playing File: {latest_audio_path} ({file_mb:.2f} MB)")

        #dynamic display file size
        root.after(0, lambda: metric_labels["audio_size"].config(text=f"{file_mb:.2f} MB", fg="darkgreen"))
        
        data, fs = sf.read(latest_audio_path)
        sd.play(data, fs)
    except Exception as e:
        messagebox.showerror("Error", f"Could not read or play audio: {e}")

        
def stop_received_audio():
    sd.stop()
    print("Audio playback killed.")

def read_subprocess_output(process):
    try:
        while True:
            line = process.stdout.readline()
            if not line:
                break
            line_str = line.decode('utf-8', errors='replace').strip()
            print(line_str)

            #live summary of the data
            clean_lower = line_str.lower().strip()

            if "telemetry algorithm" in clean_lower:
                val_part = line_str.split(":", 1)[1].strip() if ":" in line_str else line_str
                root.after(0, lambda v=val_part: metric_labels["tele_algo"].config(text=v, fg="darkgreen"))

            elif "audio algorithm" in clean_lower:
                val_part = line_str.split(":", 1)[1].strip() if ":" in line_str else line_str
                root.after(0, lambda v=val_part: metric_labels["audio_algo"].config(text=v, fg="darkgreen"))

            elif clean_lower.startswith("telemetry") and "->" in clean_lower:
                val_part = line_str.split(":", 1)[1].strip() if ":" in line_str else line_str
                root.after(0, lambda v=val_part: metric_labels["tele_size"].config(text=v, fg="blue"))

            elif clean_lower.startswith("audio") and "->" in clean_lower:
                val_part = line_str.split(":", 1)[1].strip() if ":" in line_str else line_str
                root.after(0, lambda v=val_part: metric_labels["audio_size"].config(text=v, fg="blue"))

            elif "average bandwidth:" in clean_lower:
                val_part = line_str.replace("Average Bandwidth:", "").strip()
                root.after(0, lambda v=val_part: metric_labels["bandwidth"].config(text=v, fg="magenta"))


            if line_str.startswith("PROGRESS:"):
                _, current, total = line_str.split(":")
                cur = int(current); tot = int(total)
                root.after(0, update_progress, cur, tot)
                if cur >= tot and tot > 0:
                    root.after(100, regenerate_and_plot)

            elif "all" in clean_lower and "chunks received" in clean_lower:
                root.after(0, lambda: status_label.config(text="Status: Transfer Complete! [ok]", fg="green"))
                root.after(100, regenerate_and_plot)

            elif "audio match orig:" in clean_lower:
                root.after(0, lambda: status_label.config(text="Status: Verified Lossless Match [ok]", fg="darkgreen"))
    except Exception as e:
        print(f"Error reading process output: {e}")

def update_progress(current, total):
    progress_bar["maximum"] = total
    progress_bar["value"] = current
    percentage = (current / total) * 100 if total > 0 else 0
    status_label.config(text=f"Status: Receiving Chunks ({current}/{total}) - {percentage:.1f}%", fg="blue")


def check_gnd_availability():
    global active_session
    if active_session is not None:
        status=active_session.poll()
        if status is not None:
            if status !=0:
                messagebox.showwarning("Failure", "Primary Down, Switching to Backup!")
                active_session=ground_backup()
                #adding the backup process stdout
                threading.Thread(target=read_subprocess_output, args=(active_session,), daemon=True).start()
            else:
                messagebox.showinfo("Status", "Primary closed normally")
                active_session=None
                #refresh_gui()
                #reconstruct_and_plot()
        else:
            #refresh_gui()
            root.after(1000, check_gnd_availability)

def regen_generation():
    rows = []
    for i in range(len(tele.PARAMS)):
        name = tele.PARAMS[i][0]
        rate_hz = tele.PARAMS[i][1]
        wf = tele.PARAMS[i][2]
        lo = tele.PARAMS[i][3]
        hi = tele.PARAMS[i][4] if len(tele.PARAMS[i]) > 4 else 100.0

        samples = tele._generate(name, rate_hz, wf, lo, hi, cfg.DURATION_SEC)
        rows.append((name, rate_hz, wf, lo, hi, samples, []))
    return rows

def regen_plot_data(rows):
    fig.clear()
    plottable_rows = rows[:5]
    num_plots = len(plottable_rows)
    if num_plots == 0:
        canvas.draw()
        return

    subplots = fig.subplots(num_plots, 1, sharex=True)
    fig.tight_layout(pad=1.5)

    for i, row in enumerate(plottable_rows):
        name, _, _, lo, hi, samples, _ = row
        ax = subplots[i] if num_plots > 1 else subplots
        ax.plot(samples, color=f"C{i}", linewidth=1.2)
        ax.set_title(f"Plot: {name}", fontsize=9, loc='left', pad=4)
        ax.set_ylabel(name[:12] + "...", fontsize=8, rotation=0, labelpad=35, ha='right')
        ax.set_ylim(lo - abs(lo)*0.1 if lo != 0 else -1, hi + abs(hi)*0.1 if hi != 0 else 1)
        ax.grid(True, linestyle="--", alpha=0.5)

    canvas.draw()

def regenerate_and_plot():
    try:
        rows = regen_generation()
        regen_plot_data(rows)
        status_label.config(text="Status: Displaying regenerated telemetry [sim]", fg="darkgreen")
    except Exception as e:
        messagebox.showerror("Error", f"Could not regenerate/plot telemetry: {e}")

def warning_pop():
    messagebox.showwarning("Not Authorized!", "Please give correct credentials")

def clear_metrics_dashboard():
    for label in metric_labels.values():
        label.config(text="--", fg="blue")


def ground_helper():
    global active_session
    username=entry1.get().strip()
    password=entry2.get().strip()

    if username == "Shubham" and password =="1234":
        try:
            clear_metrics_dashboard()
            active_session=ground_primary()
            messagebox.showinfo("Status", "Primary ground station is active..")

            threading.Thread(target=read_subprocess_output, args=(active_session,), daemon=True).start()
            status_label.config(text="Status: Connected. Listening for aircraft...", fg="orange")

            check_gnd_availability()
        except FileNotFoundError:
            messagebox.showerror("Error", "No ground script is found.")
        except Exception as e:
            messagebox.showwarning("Primary Failed", f"could not launch primary: {e}. Starting Backup.")
            active_session=ground_backup()

            threading.Thread(target=read_subprocess_output, args=(active_session,), daemon=True).start()
    else:
        warning_pop()

def ground_primary():
    python_executable = sys.executable
    return subprocess.Popen(
        [
            python_executable,
            "-u", #forces unbuffered standard binary o/p which has the metrics
            "ground.py",
            "--port",
            str(cfg.GROUND_STATIONS[0]["port"]),
            "--name",
            "GS-Primary",
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT
    )

def ground_backup():
    python_executable=sys.executable
    return subprocess.Popen(
        [
            python_executable,
            "-u",
            "ground.py",
            "--port",
            str(cfg.GROUND_STATIONS[1]["port"]),
            "--name",
            "GS-Backup",
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT
    )

root=tk.Tk()
root.title("Client")
root.geometry("1100x580")

control_frame = tk.Frame(root, padx=15, pady=15)
control_frame.pack(side=tk.LEFT, fill=tk.Y)

label=tk.Label(control_frame, text="Ground System")
label.grid(row=0,column=0,columnspan=2,pady=10)

gnd_user=tk.Label(control_frame,text="Ground User ")
gnd_user.grid(row=1,column=0,padx=10,pady=5)
entry1=tk.Entry(control_frame)
entry1.grid(row=1, column=1,padx=10,pady=5)

password=tk.Label(control_frame, text="Password ")
password.grid(row=2, column=0, padx=10, pady=5)
entry2=tk.Entry(control_frame, show="*")
entry2.grid(row=2,column=1, padx=10, pady=5)

button1=tk.Button(control_frame, text="Ground Active", width=25, command=ground_helper)
button1.grid(row=3,column=0,padx=10,pady=10)
button2=tk.Button(control_frame, text="Ground Not Active", width=25, command=root.destroy)
button2.grid(row=3,column=1,padx=10,pady=10)

btn_play_audio = tk.Button(control_frame, text="▶️ Play Received Audio", width=25, command=play_received_audio)
btn_play_audio.grid(row=4, column=0, padx=10, pady=5)

btn_stop_audio = tk.Button(control_frame, text="⏹️ Stop Playback", width=25, command=stop_received_audio)
btn_stop_audio.grid(row=4, column=1, padx=10, pady=5)

status_label = tk.Label(control_frame, text="Status: Disconnected / Idle", font=("Arial", 10), fg="gray")
status_label.grid(row=5, column=0, columnspan=2, pady=5, sticky=tk.W)

progress_bar = ttk.Progressbar(control_frame, orient="horizontal", length=380, mode="determinate")
progress_bar.grid(row=6, column=0, columnspan=2, pady=5, padx=10)

# file_listbox = tk.Listbox(control_frame, width=32, height=10)
# file_listbox.grid(row=4, column=0, columnspan=2, pady=10)

metrics_frame = tk.LabelFrame(control_frame, text="Session Summary ", font=("Arial", 10, "bold"), bg="white", padx=12, pady=10)
metrics_frame.grid(row=7, column=0, columnspan=2, pady=15, padx=10, sticky="ew")

def build_dashboard_row(label_text, dict_key, row_idx):
    title = tk.Label(metrics_frame, text=label_text, font=("Arial", 9), anchor="w")
    title.grid(row=row_idx, column=0, sticky="w", pady=2)
    val = tk.Label(metrics_frame, text="--", font=("Arial", 9, "bold"), fg="blue", anchor="e")
    val.grid(row=row_idx, column=1, sticky="e", pady=2)
    metrics_frame.grid_columnconfigure(1, weight=1)
    metric_labels[dict_key] = val

build_dashboard_row("Telemetry Algor",    "tele_algo",  0)
build_dashboard_row("Telemetry Size:",   "tele_size",  1)
build_dashboard_row("Audio Algo:",        "audio_algo", 2)
build_dashboard_row("Audio Size:",  "audio_size", 3)
build_dashboard_row("Avg BW:", "bandwidth",  4)

visual_frame = tk.Frame(root, bg="white", padx=10, pady=10)
visual_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

fig = Figure(figsize=(7, 4), dpi=100)
canvas = FigureCanvasTkAgg(fig, master=visual_frame)
canvas_widget = canvas.get_tk_widget()
canvas_widget.pack(fill=tk.BOTH, expand=True)

#refresh_gui()
root.mainloop()