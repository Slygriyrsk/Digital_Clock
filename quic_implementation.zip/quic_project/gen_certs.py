"""
gen_certs.py — Generate self-signed TLS 1.3 certificate + key for QUIC.

QUIC (RFC 9000) mandates TLS 1.3. This creates:
  certs/quic_cert.pem   — self-signed X.509 certificate (ground server)
  certs/quic_key.pem    — private key for that certificate

Run once before starting aircraft_quic.py / ground_quic.py:
  python gen_certs.py
"""

import datetime
import os

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID

CERT_DIR  = "certs"
CERT_PATH = "certs/quic_cert.pem"
KEY_PATH  = "certs/quic_key.pem"


def gen_certs():
    os.makedirs(CERT_DIR, exist_ok=True)

    # EC P-256 key (same curve as ECDSA signing key — consistent)
    key = ec.generate_private_key(ec.SECP256R1())

    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME,             "IN"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME,        "FDR-CVR Simulation"),
        x509.NameAttribute(NameOID.COMMON_NAME,              "ground-station.fdr.local"),
    ])

    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.datetime.now(datetime.timezone.utc))
        .not_valid_after(datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=3650))
        .add_extension(
            x509.SubjectAlternativeName([
                x509.DNSName("localhost"),
                x509.IPAddress(__import__("ipaddress").ip_address("127.0.0.1")),
            ]),
            critical=False,
        )
        .sign(key, hashes.SHA256())
    )

    with open(KEY_PATH, "wb") as f:
        f.write(key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption(),
        ))

    with open(CERT_PATH, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))

    print(f"[CERTS] Generated TLS 1.3 certificate for QUIC:")
    print(f"  Certificate : {CERT_PATH}")
    print(f"  Private key : {KEY_PATH}")
    print(f"  Valid until : {cert.not_valid_after_utc.date()}")
    print(f"  SAN         : localhost / 127.0.0.1")
    print()
    print("  These are used by ground_quic.py (server) and aircraft_quic.py (client).")
    print("  In production, replace with CA-signed certs from your PKI.")


if __name__ == "__main__":
    gen_certs()
